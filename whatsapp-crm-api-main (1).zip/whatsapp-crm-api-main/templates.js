'use strict';
/**
 * Templates, button structure and template sending for the WhatsApp CRM service.
 *
 *  - Templates are stored in templates.json (same style as automation-config.json).
 *  - Buttons: quick_reply / url / phone. WhatsApp Web has no real interactive buttons,
 *    so they are rendered as clear text lines. GET /api/templates/:id/cloud-payload
 *    exports the same structure for the official WhatsApp Business Cloud API.
 *  - Sending runs on the server (not in the browser tab), one message at a time with a
 *    pause, skips opted-out numbers, duplicates and recent repeats, and never claims
 *    "delivered": the best status is "submitted" (WhatsApp accepted it).
 *
 * All routes live under /api, so they are protected by authenticateApi in server.js.
 */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const CATEGORIES = ['Business Promotion', 'Real Estate', 'Digital Marketing', 'Offers', 'Customer Follow-up', 'Appointment', 'Welcome Message', 'Payment Reminder'];
const BUTTON_TYPES = ['quick_reply', 'url', 'phone'];
const OPTOUT_WORDS = ['stop', 'unsubscribe', 'opt out', 'optout', 'opt-out', 'stop all'];
const PHONE_KEYS = ['phone', 'number', 'mobile', 'telephone', 'phone number', 'whatsapp', 'cnumber'];
// {{name}} (preferred) and {Name} (the style the Broadcast tab already uses)
const VAR_RE = /\{\{\s*([^{}\s][^{}]*?)\s*\}\}|\{([A-Za-z0-9_][A-Za-z0-9_ .-]*?)\}/g;
const DAY = 24 * 60 * 60 * 1000;

const httpErr = (status, message) => Object.assign(new Error(message), { status });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ───────────────────────── pure helpers (exported for tests) ─────────────────────────
function cleanButtons(input) {
  if (input == null) return [];
  if (!Array.isArray(input)) throw httpErr(400, 'buttons must be a list.');
  if (input.length > 10) throw httpErr(400, 'A template can have at most 10 buttons.');
  const out = input.map((b, i) => {
    const type = b && b.type;
    const title = String((b && b.title) || '').trim();
    const value = String((b && b.value) || '').trim();
    const n = `Button ${i + 1}`;
    if (!BUTTON_TYPES.includes(type)) throw httpErr(400, `${n}: choose a type (quick_reply, url or phone).`);
    if (!title) throw httpErr(400, `${n}: add a title.`);
    if (title.length > 25) throw httpErr(400, `${n}: title can be at most 25 characters.`);
    if (type === 'url' && !/^https?:\/\/\S+$/i.test(value)) throw httpErr(400, `${n}: enter a full web address starting with http:// or https://.`);
    if (type === 'phone' && !/^\+?[\d\s()-]{7,20}$/.test(value)) throw httpErr(400, `${n}: enter a phone number with country code.`);
    return { type, title, value: type === 'quick_reply' ? '' : value };
  });
  if (out.filter((b) => b.type === 'url').length > 2) throw httpErr(400, 'At most 2 website buttons are allowed.');
  if (out.filter((b) => b.type === 'phone').length > 1) throw httpErr(400, 'At most 1 phone button is allowed.');
  return out;
}

function cleanTemplate(b = {}) {
  const name = String(b.name || '').trim();
  const body = String(b.body || '').trim();
  if (!name) throw httpErr(400, 'Give the template a name.');
  if (!body) throw httpErr(400, 'Write the message body.');
  if (body.length > 4000) throw httpErr(400, 'Message body can be at most 4000 characters.');
  const mediaUrl = String(b.mediaUrl || '').trim();
  if (mediaUrl && !/^https?:\/\/\S+$/i.test(mediaUrl)) throw httpErr(400, 'Attachment link must start with http:// or https://.');
  return {
    name: name.slice(0, 120),
    category: CATEGORIES.includes(b.category) ? b.category : CATEGORIES[0],
    title: String(b.title || '').trim().slice(0, 120),
    body,
    footer: String(b.footer || '').trim().slice(0, 160),
    mediaUrl: mediaUrl.slice(0, 1000),
    buttons: cleanButtons(b.buttons),
  };
}

const normRow = (row) => {
  const m = new Map();
  if (row && typeof row === 'object') for (const [k, v] of Object.entries(row)) m.set(String(k).trim().toLowerCase(), v == null ? '' : String(v).trim());
  return m;
};
const todayStr = () => new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

function varNames(t) {
  const text = [t.title, t.body, t.footer, ...(t.buttons || []).map((b) => b.value)].join('\n');
  const found = new Set();
  for (const m of text.matchAll(VAR_RE)) found.add((m[1] || m[2]).trim().toLowerCase());
  return [...found];
}

// Returns { text, missing }. `missing` lists variables the contact has no value for.
function render(t, row, { optOut = '', prefix = '' } = {}) {
  const vars = row instanceof Map ? row : normRow(row);
  const missing = new Set();
  const fill = (s) => String(s || '').replace(VAR_RE, (_, a, b) => {
    const key = (a || b).trim().toLowerCase();
    if (key === 'date') return todayStr();
    const v = vars.get(key);
    if (!v) { missing.add(key); return ''; }
    return v;
  }).trim();
  const parts = [];
  if (t.title) parts.push(`*${fill(t.title)}*`);
  parts.push(fill(t.body));
  if (t.buttons && t.buttons.length) {
    parts.push(t.buttons.map((b) => (b.type === 'url' ? `🔗 ${b.title}: ${fill(b.value)}`
      : b.type === 'phone' ? `📞 ${b.title}: ${fill(b.value)}`
        : `💬 Reply "${b.title}"`)).join('\n'));
  }
  if (t.footer) parts.push(`_${fill(t.footer)}_`);
  if (optOut) parts.push(`_${optOut}_`);
  return { text: prefix + parts.join('\n\n'), missing: [...missing] };
}

function pickPhone(row) {
  if (typeof row === 'string' || typeof row === 'number') return String(row);
  if (!row || typeof row !== 'object') return '';
  const lower = new Map(Object.entries(row).map(([k, v]) => [k.trim().toLowerCase(), v]));
  for (const k of PHONE_KEYS) if (lower.get(k) != null && String(lower.get(k)).trim()) return String(lower.get(k));
  for (const v of lower.values()) { const d = String(v).replace(/\D/g, ''); if (d.length >= 10 && d.length <= 15) return String(v); }
  return '';
}

function normPhone(raw, cc) {
  let d = String(raw || '').replace(/\D/g, '');
  if (String(raw || '').trim().startsWith('00')) d = d.slice(2);
  if (d && d.length <= 10 && cc) d = cc + d.replace(/^0+/, '');
  return d.length >= 8 && d.length <= 15 ? d : null;
}

// Payload for the official WhatsApp Business Cloud API (POST /{waba-id}/message_templates).
function cloudPayload(t, { language = 'en', category = 'MARKETING' } = {}) {
  const notes = [];
  const order = [];
  const pos = (s) => String(s).replace(VAR_RE, (_, a, b) => {
    const k = (a || b).trim().toLowerCase();
    if (!order.includes(k)) order.push(k);
    return `{{${order.indexOf(k) + 1}}}`;
  });
  const titleHasVar = /\{\{|\{[A-Za-z0-9_]/.test(t.title || '');
  const body = pos(titleHasVar ? `*${t.title}*\n\n${t.body}` : t.body);
  const comps = [];
  if (t.title && !titleHasVar) comps.push({ type: 'HEADER', format: 'TEXT', text: t.title.slice(0, 60) });
  const bodyC = { type: 'BODY', text: body };
  if (order.length) bodyC.example = { body_text: [order.map((k) => `Example ${k}`)] };
  comps.push(bodyC);
  if (t.footer) comps.push({ type: 'FOOTER', text: t.footer.slice(0, 60) });
  if (t.buttons && t.buttons.length) {
    const sorted = [...t.buttons].sort((a, b) => (a.type === 'quick_reply' ? 0 : 1) - (b.type === 'quick_reply' ? 0 : 1));
    comps.push({
      type: 'BUTTONS',
      buttons: sorted.map((b) => (b.type === 'quick_reply' ? { type: 'QUICK_REPLY', text: b.title }
        : b.type === 'url' ? { type: 'URL', text: b.title, url: b.value }
          : { type: 'PHONE_NUMBER', text: b.title, phone_number: `+${b.value.replace(/\D/g, '')}` })),
    });
  }
  if (/^\s*\{\{\d+\}\}/.test(body) || /\{\{\d+\}\}\s*$/.test(body)) notes.push('WhatsApp rejects bodies that start or end with a variable. Add a word before the first and after the last variable.');
  if ((t.footer || '').length > 60) notes.push('Footer was cut to 60 characters (WhatsApp limit).');
  if (varNames({ title: '', body: '', footer: t.footer, buttons: [] }).length) notes.push('Footers cannot contain variables for the Cloud API.');
  if ((t.buttons || []).some((b) => varNames({ title: '', body: '', footer: '', buttons: [b] }).length)) notes.push('Button destinations must be fixed values for the Cloud API.');
  if (t.mediaUrl) notes.push('Attachments are not included. Cloud templates need an uploaded media handle.');
  if (t.buttons && t.buttons.some((b) => b.type === 'quick_reply') && t.buttons.some((b) => b.type !== 'quick_reply')) notes.push('Quick replies are listed first because WhatsApp requires button types to be grouped.');
  const name = String(t.name).toLowerCase().replace(/[^a-z0-9_]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 80) || 'template';
  return { payload: { name, language, category, components: comps }, variable_order: order, notes };
}

// ───────────────────────── routes & sending ─────────────────────────
function init(app, { getClient, isReady, log = console.log, dir = __dirname, MessageMedia } = {}) {
  const F = { templates: path.join(dir, 'templates.json'), optout: path.join(dir, 'optout.json'), history: path.join(dir, 'send-history.json') };
  const read = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
  const write = (f, data) => { try { fs.writeFileSync(`${f}.tmp`, JSON.stringify(data, null, 2)); fs.renameSync(`${f}.tmp`, f); } catch (e) { log(`[templates] could not save ${path.basename(f)}: ${e.message}`); } };

  let store = read(F.templates, { nextId: 1, templates: [] });
  const optout = new Set(read(F.optout, []));
  let history = read(F.history, []);
  const jobs = new Map();
  const cc = () => (process.env.DEFAULT_COUNTRY_CODE || '91').replace(/\D/g, '');
  const dailyLimit = () => Math.max(1, parseInt(process.env.DAILY_SEND_LIMIT, 10) || 200);
  const optOutText = (on) => (on === false ? '' : process.env.OPTOUT_TEXT || 'Reply STOP to opt out.');
  const saveStore = () => write(F.templates, store);
  const saveHistory = () => { if (history.length > 5000) history = history.slice(-5000); write(F.history, history); };
  const find = (id) => store.templates.find((t) => String(t.id) === String(id));
  const mustFind = (id) => { const t = find(id); if (!t) throw httpErr(404, 'Template not found.'); return t; };
  const h = (fn) => (req, res) => Promise.resolve().then(() => fn(req, res)).catch((e) => {
    if (e.status) return res.status(e.status).json({ error: e.message });
    log(`[templates] ${req.method} ${req.path}: ${e.message}`);
    res.status(500).json({ error: `Unexpected error: ${e.message}` });
  });

  // ---- templates CRUD
  app.get('/api/templates', h((req, res) => {
    const q = String(req.query.q || '').toLowerCase();
    const cat = String(req.query.category || '');
    const list = store.templates.filter((t) => (!cat || t.category === cat) && (!q || `${t.name} ${t.title} ${t.body}`.toLowerCase().includes(q)));
    res.json({ templates: list.slice().sort((a, b) => b.updatedAt - a.updatedAt), categories: CATEGORIES });
  }));
  app.get('/api/templates/:id', h((req, res) => res.json(mustFind(req.params.id))));
  app.post('/api/templates', h((req, res) => {
    const t = { id: store.nextId++, ...cleanTemplate(req.body), createdAt: Date.now(), updatedAt: Date.now() };
    store.templates.push(t); saveStore();
    res.status(201).json(t);
  }));
  app.put('/api/templates/:id', h((req, res) => {
    const t = mustFind(req.params.id);
    Object.assign(t, cleanTemplate(req.body), { updatedAt: Date.now() }); saveStore();
    res.json(t);
  }));
  app.delete('/api/templates/:id', h((req, res) => {
    const t = mustFind(req.params.id);
    store.templates = store.templates.filter((x) => x !== t); saveStore();
    res.json({ success: true });
  }));
  app.post('/api/templates/:id/duplicate', h((req, res) => {
    const src = mustFind(req.params.id);
    const t = { ...JSON.parse(JSON.stringify(src)), id: store.nextId++, name: `${src.name} (copy)`.slice(0, 120), createdAt: Date.now(), updatedAt: Date.now() };
    store.templates.push(t); saveStore();
    res.status(201).json(t);
  }));
  app.get('/api/templates/:id/cloud-payload', h((req, res) => {
    res.json(cloudPayload(mustFind(req.params.id), { language: String(req.query.language || 'en'), category: req.query.category === 'UTILITY' ? 'UTILITY' : 'MARKETING' }));
  }));

  // ---- recipients: validation, skips and rendering shared by preview and send
  const sentRecently = (phone, tplId) => history.some((x) => x.status === 'submitted' && !x.test && x.templateId === tplId && x.phone === phone && Date.now() - x.ts < DAY);
  const sentToday = () => history.filter((x) => x.status === 'submitted' && !x.test && Date.now() - x.ts < DAY).length;

  function prepare(t, contacts, { appendOptOut = true, allowRepeat = false } = {}) {
    if (!Array.isArray(contacts) || !contacts.length) throw httpErr(400, 'Add at least one contact.');
    if (contacts.length > 2000) throw httpErr(400, 'Send to at most 2000 contacts at a time.');
    const seen = new Set();
    return contacts.map((row, i) => {
      const phone = normPhone(pickPhone(row), cc());
      const vars = normRow(typeof row === 'object' ? row : {});
      const name = vars.get('name') || vars.get('customer name') || '';
      const it = { index: i, phone: phone || String(pickPhone(row)), name, status: 'queued', reason: '', text: '' };
      const skip = (r) => { it.status = 'skipped'; it.reason = r; return it; };
      if (!phone) return skip('Invalid phone number');
      if (seen.has(phone)) return skip('Duplicate number in this list');
      seen.add(phone);
      if (optout.has(phone)) return skip('Opted out');
      if (!allowRepeat && sentRecently(phone, t.id)) return skip('Already received this template in the last 24 hours');
      vars.set('phone', vars.get('phone') || `+${phone}`);
      const r = render(t, vars, { optOut: optOutText(appendOptOut) });
      if (r.missing.length) return skip(`Missing ${r.missing.map((m) => `{${m}}`).join(', ')}`);
      it.text = r.text;
      return it;
    });
  }
  const view = (it) => ({ index: it.index, phone: it.phone, name: it.name, status: it.status, reason: it.reason });

  app.post('/api/templates/:id/preview', h((req, res) => {
    const t = mustFind(req.params.id);
    const items = prepare(t, req.body.contacts, { appendOptOut: req.body.appendOptOut !== false, allowRepeat: Boolean(req.body.allowRepeat) });
    res.json({
      total: items.length,
      queued: items.filter((x) => x.status === 'queued').length,
      skipped: items.filter((x) => x.status === 'skipped').map(view),
      samples: items.filter((x) => x.status === 'queued').slice(0, 3).map((x) => ({ phone: x.phone, name: x.name, text: x.text })),
    });
  }));

  // ---- sending
  async function loadMedia(url) {
    const MM = MessageMedia || require('whatsapp-web.js').MessageMedia;
    let resp;
    try { resp = await fetch(url, { signal: AbortSignal.timeout(20000) }); } catch (e) { throw httpErr(400, `Could not download the attachment: ${e.message}`); }
    if (!resp.ok) throw httpErr(400, `Could not download the attachment (HTTP ${resp.status}).`);
    const buf = Buffer.from(await resp.arrayBuffer());
    if (buf.length > 16 * 1024 * 1024) throw httpErr(400, 'The attachment is larger than 16 MB.');
    const mime = (resp.headers.get('content-type') || 'application/octet-stream').split(';')[0];
    return new MM(mime, buf.toString('base64'), decodeURIComponent(new URL(url).pathname.split('/').pop() || 'file'));
  }

  const record = (job, it, test = false) => {
    history.push({ ts: Date.now(), jobId: job ? job.id : null, templateId: job ? job.templateId : it.templateId, template: job ? job.templateName : it.template, phone: it.phone, name: it.name, status: it.status, error: it.status === 'failed' ? it.reason : '', test });
    saveHistory();
  };

  async function runJob(job, media) {
    const client = getClient();
    const queuedLeft = () => job.items.some((x) => x.status === 'queued');
    const abort = (msg) => { job.error = msg; job.items.forEach((x) => { if (x.status === 'queued') { x.status = 'skipped'; x.reason = 'Not sent: job stopped'; } }); };
    try {
      for (const it of job.items) {
        if (it.status !== 'queued') continue;
        if (job.stopRequested) { it.status = 'skipped'; it.reason = 'Stopped before sending'; continue; }
        if (!isReady()) { abort('WhatsApp disconnected. The remaining messages were not sent.'); break; }
        if (optout.has(it.phone)) { it.status = 'skipped'; it.reason = 'Opted out before sending'; continue; }
        it.status = 'sending';
        try {
          const numberId = await client.getNumberId(it.phone);
          if (!numberId) throw new Error('This number is not registered on WhatsApp');
          if (media) await client.sendMessage(numberId._serialized, media, { caption: it.text, sendSeen: false });
          else await client.sendMessage(numberId._serialized, it.text, { sendSeen: false });
          it.status = 'submitted';
        } catch (e) {
          it.status = 'failed'; it.reason = String(e.message).slice(0, 300);
          if (/detached Frame/i.test(e.message)) { record(job, it); abort('The WhatsApp session dropped. Reconnect, then resend the remaining numbers.'); break; }
        }
        record(job, it);
        if (queuedLeft() && !job.stopRequested) await sleep(Math.max(3000, job.delay * 1000 * (0.8 + Math.random() * 0.4)));
      }
    } catch (e) { abort(`Unexpected error: ${e.message}`); log(`[templates] job ${job.id}: ${e.stack || e.message}`); }
    job.status = job.stopRequested || job.error ? 'stopped' : 'completed';
    job.finishedAt = Date.now();
    log(`[templates] job ${job.id} ${job.status}: ${job.items.filter((x) => x.status === 'submitted').length} submitted, ${job.items.filter((x) => x.status === 'failed').length} failed`);
  }

  const jobView = (j) => ({
    id: j.id, templateId: j.templateId, templateName: j.templateName, status: j.status, error: j.error || '', delay: j.delay, startedAt: j.startedAt, finishedAt: j.finishedAt || null,
    counts: ['queued', 'sending', 'submitted', 'failed', 'skipped'].reduce((a, s) => ({ ...a, [s]: j.items.filter((x) => x.status === s).length }), { total: j.items.length }),
    items: j.items.map(view),
  });

  app.post('/api/templates/:id/send', h(async (req, res) => {
    const t = mustFind(req.params.id);
    const b = req.body || {};
    if (b.confirmOptIn !== true) throw httpErr(400, 'Confirm that every recipient has agreed to receive messages from you.');
    if (b.requestId) { const dup = [...jobs.values()].find((j) => j.requestId === b.requestId); if (dup) return res.status(200).json({ jobId: dup.id, duplicate: true, job: jobView(dup) }); }
    if (!isReady()) throw httpErr(503, 'WhatsApp client is not ready.');
    if ([...jobs.values()].some((j) => j.status === 'running')) throw httpErr(409, 'Another send is already running. Wait for it to finish or stop it first.');
    const items = prepare(t, b.contacts, { appendOptOut: b.appendOptOut !== false, allowRepeat: Boolean(b.allowRepeat) });
    const queued = items.filter((x) => x.status === 'queued').length;
    if (!queued) throw httpErr(400, `No one to send to. ${[...new Set(items.map((x) => x.reason))].join('; ')}.`);
    const room = dailyLimit() - sentToday();
    if (queued > room) throw httpErr(400, `The 24-hour limit is ${dailyLimit()} messages and ${dailyLimit() - Math.max(0, room)} were already sent. You can send ${Math.max(0, room)} more now.`);
    const media = t.mediaUrl ? await loadMedia(t.mediaUrl) : null;
    const job = { id: crypto.randomUUID(), requestId: b.requestId || null, templateId: t.id, templateName: t.name, status: 'running', delay: Math.max(3, Math.min(120, parseFloat(b.delay) || 8)), items, startedAt: Date.now(), stopRequested: false, error: '' };
    jobs.set(job.id, job);
    if (jobs.size > 20) jobs.delete(jobs.keys().next().value);
    runJob(job, media);
    res.status(202).json({ jobId: job.id, queued, job: jobView(job) });
  }));

  app.post('/api/templates/:id/send-test', h(async (req, res) => {
    const t = mustFind(req.params.id);
    if (!isReady()) throw httpErr(503, 'WhatsApp client is not ready.');
    const client = getClient();
    const own = client.info && client.info.wid && client.info.wid.user;
    const phone = normPhone(req.body.phone || own, cc());
    if (!phone) throw httpErr(400, 'Enter a test number with country code.');
    const vars = normRow(req.body.vars || { name: 'Test' });
    vars.set('phone', vars.get('phone') || `+${phone}`);
    const { text } = render(t, vars, { optOut: optOutText(true), prefix: '[TEST] ' });
    const it = { phone, name: 'Test', status: 'failed', reason: '', templateId: t.id, template: t.name };
    try {
      const numberId = await client.getNumberId(phone);
      if (!numberId) throw new Error('This number is not registered on WhatsApp');
      if (t.mediaUrl) await client.sendMessage(numberId._serialized, await loadMedia(t.mediaUrl), { caption: text, sendSeen: false });
      else await client.sendMessage(numberId._serialized, text, { sendSeen: false });
      it.status = 'submitted';
    } catch (e) { it.reason = String(e.message).slice(0, 300); record(null, it, true); throw httpErr(e.status || 502, it.reason); }
    record(null, it, true);
    res.json({ success: true, phone, status: 'submitted', note: 'WhatsApp accepted the message. Check your phone to confirm it arrived.' });
  }));

  app.get('/api/send-jobs', h((req, res) => res.json({ jobs: [...jobs.values()].reverse().slice(0, 10).map((j) => ({ ...jobView(j), items: undefined })) })));
  app.get('/api/send-jobs/:id', h((req, res) => { const j = jobs.get(req.params.id); if (!j) throw httpErr(404, 'Send job not found (jobs are kept in memory until restart).'); res.json(jobView(j)); }));
  app.post('/api/send-jobs/:id/stop', h((req, res) => { const j = jobs.get(req.params.id); if (!j) throw httpErr(404, 'Send job not found.'); j.stopRequested = true; res.json({ success: true }); }));
  app.get('/api/send-history', h((req, res) => res.json({ history: history.slice(-Math.min(1000, parseInt(req.query.limit, 10) || 200)).reverse(), sentLast24h: sentToday(), limit: dailyLimit() })));

  // ---- opt-outs
  app.get('/api/optout', h((req, res) => res.json({ numbers: [...optout] })));
  app.post('/api/optout', h((req, res) => {
    const p = normPhone(req.body.phone, cc());
    if (!p) throw httpErr(400, 'Enter a valid number with country code.');
    optout.add(p); write(F.optout, [...optout]); res.json({ numbers: [...optout] });
  }));
  app.delete('/api/optout/:phone', h((req, res) => { optout.delete(String(req.params.phone).replace(/\D/g, '')); write(F.optout, [...optout]); res.json({ numbers: [...optout] }); }));

  // Called from server.js for every incoming message. Returns true when it was an opt-out request.
  async function handleIncoming(msg) {
    try {
      if (!msg || msg.fromMe || String(msg.from).endsWith('@g.us') || msg.from === 'status@broadcast') return false;
      const text = String(msg.body || '').trim().toLowerCase().replace(/[.!\s]+$/, '');
      if (!OPTOUT_WORDS.includes(text)) return false;
      let phone = '';
      try { phone = String((await msg.getContact()).number || ''); } catch { /* use chat id */ }
      phone = (phone || String(msg.from).split('@')[0]).replace(/\D/g, '');
      if (!phone) return false;
      optout.add(phone); write(F.optout, [...optout]);
      log(`[templates] +${phone} opted out`);
      try { await getClient().sendMessage(msg.from, 'You have been unsubscribed and will not receive more messages from us.'); } catch { /* best effort */ }
      return true;
    } catch (e) { log(`[templates] opt-out handling failed: ${e.message}`); return false; }
  }

  return { handleIncoming, _state: { store, optout, get history() { return history; }, jobs } };
}

module.exports = init;
module.exports.helpers = { cleanTemplate, cleanButtons, render, varNames, pickPhone, normPhone, cloudPayload, CATEGORIES };
