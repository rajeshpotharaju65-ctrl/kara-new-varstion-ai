'use strict';
// Run with: npm test   (uses a fake WhatsApp client, nothing is really sent)
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const express = require('express');
const init = require('../templates');
const { cleanButtons, render, cloudPayload } = init.helpers;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function setup(ready = true) {
  const sent = [];
  const client = {
    info: { wid: { user: '919000000000' } },
    getNumberId: async (p) => (p === '919000000099' ? null : { _serialized: `${p}@c.us` }),
    sendMessage: async (jid, content, opts) => { sent.push({ jid, content, opts }); return { id: { id: 'x' } }; },
  };
  const state = { ready };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tpl-'));
  const app = express();
  app.use(express.json());
  const mod = init(app, { getClient: () => client, isReady: () => state.ready, log: () => {}, dir });
  return new Promise((resolve) => {
    const server = app.listen(0, () => {
      const base = `http://127.0.0.1:${server.address().port}`;
      const call = async (method, url, body) => {
        const r = await fetch(base + url, { method, headers: { 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
        return { status: r.status, body: await r.json() };
      };
      resolve({ call, sent, state, mod, dir, close: () => server.close() });
    });
  });
}

test('button validation', () => {
  assert.deepEqual(cleanButtons([{ type: 'quick_reply', title: 'Yes' }]), [{ type: 'quick_reply', title: 'Yes', value: '' }]);
  assert.throws(() => cleanButtons([{ type: 'url', title: 'Site', value: 'nope' }]), /full web address/);
  assert.throws(() => cleanButtons([{ type: 'phone', title: 'Call', value: 'abc' }]), /phone number/);
  assert.throws(() => cleanButtons([{ type: 'quick_reply', title: 'x'.repeat(26) }]), /25 characters/);
  assert.throws(() => cleanButtons([{ type: 'phone', title: 'A', value: '+911234567890' }, { type: 'phone', title: 'B', value: '+911234567891' }]), /At most 1 phone/);
  assert.throws(() => cleanButtons([{ type: 'url', title: 'A', value: 'http://a.io' }, { type: 'url', title: 'B', value: 'http://b.io' }, { type: 'url', title: 'C', value: 'http://c.io' }]), /At most 2 website/);
});

test('render: both variable styles, case-insensitive, buttons as text, missing detection', () => {
  const t = { title: 'Hi {{name}}', body: 'Offer from {Business} for {{ NAME }}', footer: 'GSRR', buttons: [{ type: 'url', title: 'Visit', value: 'https://x.io' }, { type: 'quick_reply', title: 'Tell me more', value: '' }, { type: 'phone', title: 'Call', value: '+919876543210' }] };
  const r = render(t, { Name: 'Ravi', business: 'Ravi Realty' }, { optOut: 'Reply STOP to opt out.' });
  assert.equal(r.missing.length, 0);
  assert.match(r.text, /^\*Hi Ravi\*\n\nOffer from Ravi Realty for Ravi/);
  assert.match(r.text, /🔗 Visit: https:\/\/x\.io\n💬 Reply "Tell me more"\n📞 Call: \+919876543210/);
  assert.match(r.text, /_GSRR_\n\n_Reply STOP to opt out\._$/);
  assert.deepEqual(render(t, { name: 'A' }).missing, ['business']);
});

test('cloud payload: positional variables, grouped buttons, warnings', () => {
  const { payload, variable_order, notes } = cloudPayload({ name: 'Festival Offer!', title: 'Big sale', body: '{{name}}, get 10% off at {{business}} today', footer: 'GSRR', buttons: [{ type: 'url', title: 'Shop', value: 'https://x.io' }, { type: 'quick_reply', title: 'Later', value: '' }] });
  assert.equal(payload.name, 'festival_offer');
  assert.deepEqual(variable_order, ['name', 'business']);
  assert.equal(payload.components.find((c) => c.type === 'BODY').text, '{{1}}, get 10% off at {{2}} today');
  assert.equal(payload.components.find((c) => c.type === 'BUTTONS').buttons[0].type, 'QUICK_REPLY');
  assert.ok(notes.some((n) => /start or end with a variable/.test(n)));
});

test('template CRUD, duplicate, validation', async () => {
  const s = await setup();
  assert.equal((await s.call('POST', '/api/templates', { name: '', body: 'x' })).status, 400);
  const c = await s.call('POST', '/api/templates', { name: 'Welcome', category: 'Welcome Message', body: 'Hello {{name}}', buttons: [{ type: 'quick_reply', title: 'Hi' }] });
  assert.equal(c.status, 201);
  const id = c.body.id;
  assert.equal((await s.call('PUT', `/api/templates/${id}`, { name: 'Welcome 2', body: 'Hello {{name}}!' })).body.name, 'Welcome 2');
  const d = await s.call('POST', `/api/templates/${id}/duplicate`);
  assert.equal(d.body.name, 'Welcome 2 (copy)');
  assert.equal((await s.call('GET', '/api/templates?q=copy')).body.templates.length, 1);
  assert.equal((await s.call('DELETE', `/api/templates/${d.body.id}`)).status, 200);
  assert.equal((await s.call('GET', `/api/templates/${d.body.id}`)).status, 404);
  assert.ok(fs.existsSync(path.join(s.dir, 'templates.json')));
  s.close();
});

test('preview skips invalid, duplicate, missing-variable and opted-out numbers', async () => {
  const s = await setup();
  const id = (await s.call('POST', '/api/templates', { name: 'T', body: 'Hi {{name}} from {{business}}' })).body.id;
  await s.call('POST', '/api/optout', { phone: '+91 90000 00004' });
  const p = await s.call('POST', `/api/templates/${id}/preview`, { contacts: [
    { Phone: '9000000001', Name: 'A', Business: 'X' },
    { Phone: '9000000001', Name: 'A', Business: 'X' },
    { Phone: '12', Name: 'B', Business: 'X' },
    { Phone: '9000000003', Name: 'C' },
    { Phone: '9000000004', Name: 'D', Business: 'X' },
  ] });
  assert.equal(p.body.queued, 1);
  assert.deepEqual(p.body.skipped.map((x) => x.reason), ['Duplicate number in this list', 'Invalid phone number', 'Missing {business}', 'Opted out']);
  assert.equal(p.body.samples[0].text.split('\n')[0], 'Hi A from X');
  s.close();
});

test('send: consent required, sequential, honest statuses, no repeats, one job at a time, stop, idempotency', async () => {
  const s = await setup();
  const id = (await s.call('POST', '/api/templates', { name: 'T', body: 'Hi {{name}}', buttons: [{ type: 'url', title: 'Site', value: 'https://x.io' }] })).body.id;
  const contacts = [{ phone: '9000000001', name: 'A' }, { phone: '919000000099', name: 'NoWA' }, { phone: '9000000002', name: 'B' }];

  assert.equal((await s.call('POST', `/api/templates/${id}/send`, { contacts })).status, 400, 'needs confirmOptIn');
  s.state.ready = false;
  assert.equal((await s.call('POST', `/api/templates/${id}/send`, { contacts, confirmOptIn: true })).status, 503);
  s.state.ready = true;

  const r = await s.call('POST', `/api/templates/${id}/send`, { contacts, confirmOptIn: true, delay: 3, requestId: 'r1' });
  assert.equal(r.status, 202);
  assert.equal(r.body.queued, 3);
  assert.equal((await s.call('POST', `/api/templates/${id}/send`, { contacts, confirmOptIn: true, requestId: 'r1' })).body.duplicate, true, 'double click reuses job');
  assert.equal((await s.call('POST', `/api/templates/${id}/send`, { contacts: [{ phone: '9000000077', name: 'Z' }], confirmOptIn: true })).status, 409, 'one job at a time');

  let job;
  for (let i = 0; i < 40; i++) { await sleep(500); job = (await s.call('GET', `/api/send-jobs/${r.body.jobId}`)).body; if (job.status !== 'running') break; }
  assert.equal(job.status, 'completed');
  assert.deepEqual(job.items.map((x) => x.status), ['submitted', 'failed', 'submitted']);
  assert.match(job.items[1].reason, /not registered/);
  assert.equal(s.sent.length, 2);
  assert.match(s.sent[0].content, /^Hi A\n\n🔗 Site: https:\/\/x\.io\n\n_Reply STOP to opt out\._$/);
  assert.ok(!JSON.stringify(job).includes('delivered'));

  const again = await s.call('POST', `/api/templates/${id}/send`, { contacts, confirmOptIn: true });
  assert.equal(again.body.queued, 1, 'only the failed number is retried; others got it in the last 24h');
  await s.call('POST', `/api/send-jobs/${again.body.jobId}/stop`);
  for (let i = 0; i < 20; i++) { await sleep(300); if ((await s.call('GET', `/api/send-jobs/${again.body.jobId}`)).body.status !== 'running') break; }
  const hist = (await s.call('GET', '/api/send-history')).body;
  assert.equal(hist.history.filter((x) => x.status === 'submitted').length, 2);
  s.close();
});

test('incoming STOP opts the number out; send-test goes to own number; daily cap', async () => {
  const s = await setup();
  const id = (await s.call('POST', '/api/templates', { name: 'T', body: 'Hi {{name}}' })).body.id;
  const replies = [];
  const msg = { from: '919000000005@c.us', body: ' STOP. ', fromMe: false, getContact: async () => ({ number: '919000000005' }) };
  assert.equal(await s.mod.handleIncoming(msg), true);
  assert.equal(await s.mod.handleIncoming({ ...msg, body: 'what is the price?' }), false);
  assert.deepEqual((await s.call('GET', '/api/optout')).body.numbers, ['919000000005']);
  const p = await s.call('POST', `/api/templates/${id}/preview`, { contacts: [{ phone: '919000000005', name: 'X' }] });
  assert.equal(p.body.skipped[0].reason, 'Opted out');

  const t = await s.call('POST', `/api/templates/${id}/send-test`, {});
  assert.equal(t.body.phone, '919000000000');
  assert.match(s.sent.at(-1).content, /^\[TEST\] \*?Hi Test/);

  process.env.DAILY_SEND_LIMIT = '1';
  const r = await s.call('POST', `/api/templates/${id}/send`, { contacts: [{ phone: '9000000011', name: 'A' }, { phone: '9000000012', name: 'B' }], confirmOptIn: true });
  assert.equal(r.status, 400);
  assert.match(r.body.error, /24-hour limit is 1/);
  delete process.env.DAILY_SEND_LIMIT;
  s.close();
});
