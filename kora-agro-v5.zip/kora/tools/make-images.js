'use strict';
/**
 * Draws the product pictures, link-preview image and app icons.
 *   node tools/make-images.js
 * Needs Playwright (dev only, the store itself has no dependencies).
 * To use your own real photos instead: put files named 1.jpg ... 12.jpg in public/img/products/.
 */
const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');

const ROOT = path.join(__dirname, '..', 'public');
const FONT = "'DM Sans','Helvetica Neue',Arial,sans-serif";

/* ------------------------------------------------------------------ shared bits */
const kora = (x, y, size, fill = '#17433A', dot = '#F2B23A') =>
  `<text x="${x}" y="${y}" font-family="${FONT}" font-weight="800" font-size="${size}" fill="${fill}" text-anchor="middle" letter-spacing="-1">kora<tspan fill="${dot}">.</tspan></text>`;
const txt = (x, y, s, size, fill, weight = 700, extra = '') =>
  `<text x="${x}" y="${y}" font-family="${FONT}" font-weight="${weight}" font-size="${size}" fill="${fill}" text-anchor="middle" ${extra}>${s}</text>`;
const shadow = (cx, cy, rx) => `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${rx * 0.075}" fill="#0b1f19" opacity=".22" filter="url(#blur)"/>`;

const scene = (bg1, bg2, inner) => `<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="900" viewBox="0 0 1200 900">
<defs>
  <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${bg1}"/><stop offset="1" stop-color="${bg2}"/></linearGradient>
  <radialGradient id="glow" cx=".5" cy=".42" r=".55"><stop offset="0" stop-color="#fff" stop-opacity=".85"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
  <linearGradient id="sheen" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#fff" stop-opacity=".28"/><stop offset=".35" stop-color="#fff" stop-opacity="0"/><stop offset=".8" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".16"/></linearGradient>
  <pattern id="crimp" width="9" height="10" patternUnits="userSpaceOnUse"><rect width="9" height="10" fill="none"/><path d="M0 0v10" stroke="#000" stroke-opacity=".16" stroke-width="3"/></pattern>
  <filter id="blur" x="-20%" y="-300%" width="140%" height="700%"><feGaussianBlur stdDeviation="14"/></filter>
</defs>
<rect width="1200" height="900" fill="url(#bg)"/><rect width="1200" height="900" fill="url(#glow)"/>
<circle cx="1080" cy="90" r="230" fill="#fff" opacity=".28"/><circle cx="110" cy="860" r="260" fill="#fff" opacity=".22"/>
${inner}
</svg>`;

/* ------------------------------------------------------------------ pack shapes */
function packet({ x = 600, bg, dark, title, sub, weight, art }) {
  const w = 380, h = 540, L = x - w / 2, T = 150;
  return `${shadow(x, T + h + 22, 230)}
<g transform="translate(${L},${T})">
  <path d="M0 14Q0 0 14 0H${w - 14}Q${w} 0 ${w} 14V${h - 14}Q${w} ${h} ${w - 14} ${h}H14Q0 ${h} 0 ${h - 14}Z" fill="${bg}"/>
  <rect y="0" width="${w}" height="40" rx="14" fill="${dark}"/><rect width="${w}" height="40" fill="url(#crimp)"/>
  <rect y="${h - 40}" width="${w}" height="40" rx="14" fill="${dark}"/><rect y="${h - 40}" width="${w}" height="40" fill="url(#crimp)"/>
  <rect x="26" y="72" width="${w - 52}" height="${h - 144}" rx="22" fill="#fffdf8"/>
  ${kora(w / 2, 125, 38)}
  <line x1="120" y1="143" x2="${w - 120}" y2="143" stroke="#e6e0d0" stroke-width="3"/>
  <circle cx="${w / 2}" cy="240" r="84" fill="${bg}" opacity=".16"/>
  <g transform="translate(${w / 2},240) scale(.92)">${art}</g>
  ${txt(w / 2, 368, title, 31, '#13201B', 800)}
  ${txt(w / 2, 397, sub, 18, '#5B6A63', 500)}
  <rect x="${w / 2 - 62}" y="${h - 118}" width="124" height="34" rx="17" fill="${bg}"/>${txt(w / 2, h - 94, weight, 19, '#fff', 700)}
  <rect width="${w}" height="${h}" rx="14" fill="url(#sheen)"/>
</g>`;
}

function sack({ x = 600, bg, dark, title, sub, weight, art }) {
  const w = 440, h = 560, L = x - w / 2, T = 140;
  return `${shadow(x, T + h + 24, 260)}
<g transform="translate(${L},${T})">
  <path d="M30 30Q${w / 2} 4 ${w - 30} 30L${w - 6} ${h * 0.5}Q${w + 4} ${h - 30} ${w - 26} ${h - 6}Q${w / 2} ${h + 10} 26 ${h - 6}Q-4 ${h - 30} 6 ${h * 0.5}Z" fill="${bg}"/>
  <path d="M30 30Q${w / 2} 4 ${w - 30} 30L${w - 24} 92Q${w / 2} 112 24 92Z" fill="${dark}"/>
  <path d="M40 66Q${w / 2} 86 ${w - 40} 66" stroke="#fff" stroke-opacity=".55" stroke-width="4" stroke-dasharray="14 10" fill="none"/>
  <rect x="58" y="150" width="${w - 116}" height="${h - 230}" rx="24" fill="#fffdf8"/>
  ${kora(w / 2, 205, 40)}
  <line x1="150" y1="224" x2="${w - 150}" y2="224" stroke="#e6e0d0" stroke-width="3"/>
  <g transform="translate(${w / 2},300) scale(.9)">${art}</g>
  ${txt(w / 2, 396, title, 32, '#13201B', 800)}
  ${txt(w / 2, 424, sub, 18, '#5B6A63', 500)}
  <rect x="${w / 2 - 66}" y="${h - 124}" width="132" height="36" rx="18" fill="${dark}"/>${txt(w / 2, h - 99, weight, 20, '#fff', 700)}
  <path d="M30 30Q${w / 2} 4 ${w - 30} 30L${w - 6} ${h * 0.5}Q${w + 4} ${h - 30} ${w - 26} ${h - 6}Q${w / 2} ${h + 10} 26 ${h - 6}Q-4 ${h - 30} 6 ${h * 0.5}Z" fill="url(#sheen)"/>
</g>`;
}

/* ------------------------------------------------------------------ little illustrations */
const A = {
  tomato: `<circle r="62" fill="#e5392b"/><ellipse cx="-22" cy="-24" rx="16" ry="10" fill="#fff" opacity=".35" transform="rotate(-30 -22 -24)"/>
    <path d="M0-60l-10 16-22-4 14 14-14 14 22-2 10 16 10-16 22 2-14-14 14-14-22 4z" fill="#3c8d3f" transform="scale(.7) translate(0 -22)"/>
    <circle cx="62" cy="38" r="30" fill="#e5392b" transform="scale(.7)"/>`,
  chilli: `<path d="M-30-52C10-70 54-34 52 22 50 64 32 84 20 72 14 62 26 40 18 8 8-26-14-40-30-52Z" fill="#b8231a" transform="translate(-14 6) scale(.9)"/>
    <path d="M-44-50C20-66 64-10 54 56 48 84 28 90 22 70 26 30 6-14-44-30Z" fill="#e0301f"/><path d="M-44-50c-10-10-8-26 8-28 10-2 18 6 14 16-4 10-14 18-22 12z" fill="#3c8d3f"/>
    <path d="M26-18c16 14 22 40 14 70" stroke="#fff" stroke-opacity=".45" stroke-width="7" fill="none" stroke-linecap="round"/>`,
  corn: `<path d="M-30 70C-62 24-48-52 0-76 48-52 62 24 30 70-10 84-20 84-30 70Z" fill="#f6c33b"/>
    <g fill="#e2a41d" opacity=".75">${[-30, -10, 10, 30].map(x => [-50, -26, -2, 22, 46].map(y => `<ellipse cx="${x}" cy="${y}" rx="8" ry="10"/>`).join('')).join('')}</g>
    <path d="M-34 78C-80 20-58-40-26-30-40 10-26 50 0 82Z" fill="#4f9d3a"/><path d="M34 78C80 20 58-40 26-30 40 10 26 50 0 82Z" fill="#3c8d3f"/>`,
  worm: `<circle r="82" fill="#6b4226" opacity=".18"/><path d="M-62 28C-40-30-10 40 12-8 28-42 52-10 62-34" stroke="#b5654a" stroke-width="22" fill="none" stroke-linecap="round"/>
    <path d="M-62 28C-40-30-10 40 12-8 28-42 52-10 62-34" stroke="#d98b6d" stroke-width="8" fill="none" stroke-linecap="round" stroke-dasharray="3 14"/>
    <circle cx="58" cy="-36" r="3" fill="#2a1a10"/><path d="M-70 62h140" stroke="#6b4226" stroke-width="10" stroke-linecap="round" opacity=".5"/>
    <path d="M-30 54c0-26 14-26 14-40 0 14 14 14 14 40z" fill="#3c8d3f" transform="translate(40 -6) scale(.8)"/>`,
  neemleaf: `<g fill="#3c8d3f"><path d="M0 70V-60" stroke="#2c6b30" stroke-width="7" stroke-linecap="round"/>
    ${[[-52, -40, -28], [52, -40, 28], [-58, -4, -34], [58, -4, 34], [-52, 32, -36], [52, 32, 36]].map(([x, y, r]) => `<ellipse cx="${x * 0.6}" cy="${y}" rx="30" ry="12" transform="rotate(${r} ${x * 0.6} ${y})"/>`).join('')}
    <ellipse cx="0" cy="-72" rx="12" ry="26"/></g>`,
  drops: `<path d="M0-78C28-36 44-12 44 14a44 44 0 01-88 0C-44-12-28-36 0-78Z" fill="#2c7fb8"/><path d="M-18 6c-4 14 2 26 16 30" stroke="#fff" stroke-opacity=".55" stroke-width="8" fill="none" stroke-linecap="round"/>`
};

/* ------------------------------------------------------------------ the 12 pictures */
const P = {
  1: () => scene('#e9f5df', '#cfe8b8', packet({ bg: '#c7352b', dark: '#8d1f19', title: 'Tomato Hybrid', sub: 'Disease-tolerant seeds', weight: '10 g', art: A.tomato })),
  2: () => scene('#fbeadc', '#f4cdb1', packet({ bg: '#2f8a46', dark: '#1d5e30', title: 'Chilli Hybrid', sub: 'Pungent · High yield', weight: '10 g', art: A.chilli })),
  3: () => scene('#fdf3cf', '#f6df8d', packet({ bg: '#e0a21a', dark: '#a8730a', title: 'Sweet Corn', sub: 'Sugary tender cobs', weight: '500 g', art: A.corn })),
  4: () => scene('#f1e8dc', '#e0cdb4', sack({ bg: '#6d8f3a', dark: '#4a6726', title: 'Vermicompost', sub: 'Organic earthworm compost', weight: '10 kg', art: A.worm })),
  5: () => scene('#e2effa', '#bcd8ef', (() => {
    const x = 600, w = 400, h = 560, L = x - w / 2, T = 150;
    return `${shadow(x, T + h + 20, 240)}<g transform="translate(${L},${T})">
      <path d="M0 24Q0 0 24 0H${w - 24}Q${w} 0 ${w} 24L${w - 12} ${h - 40}Q${w - 14} ${h} ${w - 60} ${h}H60Q14 ${h} 12 ${h - 40}Z" fill="#1f6fb2"/>
      <rect width="${w}" height="46" rx="20" fill="#154f82"/><rect width="${w}" height="46" fill="url(#crimp)"/>
      <rect x="28" y="84" width="${w - 56}" height="${h - 170}" rx="24" fill="#fff"/>
      ${kora(w / 2, 140, 36)}
      <g transform="translate(${w / 2},230) scale(.7)">${A.drops}</g>
      ${txt(w / 2, 335, '19:19:19', 62, '#154f82', 800)}
      ${txt(w / 2, 385, 'NPK Water Soluble', 26, '#13201B', 800)}
      ${txt(w / 2, 415, 'For drip &amp; foliar feeding', 19, '#5B6A63', 500)}
      <rect x="${w / 2 - 58}" y="${h - 112}" width="116" height="34" rx="17" fill="#fff"/>${txt(w / 2, h - 88, '1 kg', 20, '#154f82', 800)}
      <path d="M0 24Q0 0 24 0H${w - 24}Q${w} 0 ${w} 24L${w - 12} ${h - 40}Q${w - 14} ${h} ${w - 60} ${h}H60Q14 ${h} 12 ${h - 40}Z" fill="url(#sheen)"/></g>`;
  })()),
  6: () => scene('#f0efe3', '#dcdcb8', sack({ bg: '#8a6a2e', dark: '#5f4719', title: 'Neem Cake', sub: 'Soil conditioner · Organic', weight: '5 kg', art: A.neemleaf })),
  7: () => scene('#e6f2e2', '#c3e0b8', (() => {
    const x = 600;
    return `${shadow(x, 760, 190)}<g transform="translate(${x - 150},110)">
      <rect x="95" y="0" width="110" height="70" rx="14" fill="#2f7d32"/><rect x="95" y="0" width="110" height="70" fill="url(#crimp)"/><rect x="85" y="58" width="130" height="28" rx="10" fill="#256528"/>
      <path d="M70 86H230Q300 100 300 170V610Q300 650 262 650H38Q0 650 0 610V170Q0 100 70 86Z" fill="#b8741a"/>
      <path d="M70 86H230Q300 100 300 170V610Q300 650 262 650H38Q0 650 0 610V170Q0 100 70 86Z" fill="url(#sheen)"/>
      <rect x="22" y="220" width="256" height="330" rx="20" fill="#fffdf8"/>
      ${kora(150, 280, 40)}<line x1="95" y1="298" x2="205" y2="298" stroke="#e6e0d0" stroke-width="3"/>
      <g transform="translate(150,385) scale(.78)">${A.neemleaf}</g>
      ${txt(150, 488, 'Neem Oil', 36, '#13201B', 800)}${txt(150, 518, 'Bio-pesticide · 10000 ppm', 16, '#5B6A63', 500)}
      <rect x="95" y="565" width="110" height="34" rx="17" fill="#2f7d32"/>${txt(150, 589, '1 L', 20, '#fff', 800)}
      <rect x="215" y="150" width="14" height="420" rx="7" fill="#fff" opacity=".18"/></g>`;
  })()),
  8: () => scene('#e5f3ef', '#bfe0d6', (() => {
    const x = 600;
    return `${shadow(x, 745, 250)}<g transform="translate(${x - 220},170)">
      <path d="M30 120H410L390 540Q388 575 350 575H90Q52 575 50 540Z" fill="#f5f8f6"/>
      <path d="M30 120H410L390 540Q388 575 350 575H90Q52 575 50 540Z" fill="url(#sheen)"/>
      <rect x="10" y="40" width="420" height="96" rx="22" fill="#1b7f6a"/><rect x="10" y="40" width="420" height="96" rx="22" fill="url(#sheen)"/><rect x="24" y="26" width="392" height="30" rx="14" fill="#14604f"/>
      <rect x="62" y="200" width="316" height="300" rx="22" fill="#fff" stroke="#d6e6e0" stroke-width="3"/>
      ${kora(220, 255, 38)}<line x1="150" y1="272" x2="290" y2="272" stroke="#e6e0d0" stroke-width="3"/>
      <g transform="translate(220,350)"><path d="M0-52v104M0-8l-34 34M0 8l36 34M0-24l30-26" stroke="#1b7f6a" stroke-width="9" stroke-linecap="round" fill="none"/>
        <circle cx="-34" cy="30" r="9" fill="#a8d672"/><circle cx="36" cy="44" r="9" fill="#a8d672"/><circle cx="30" cy="-52" r="9" fill="#a8d672"/><circle cx="0" cy="-60" r="10" fill="#a8d672"/></g>
      ${txt(220, 438, 'Trichoderma', 34, '#13201B', 800)}${txt(220, 468, 'Bio-fungicide · Root protection', 16, '#5B6A63', 500)}
      <rect x="170" y="515" width="100" height="32" rx="16" fill="#1b7f6a"/>${txt(220, 538, '1 kg', 19, '#fff', 800)}</g>`;
  })()),
  9: () => scene('#fff6d1', '#fbe58a', (() => {
    const sheet = (i, rot, dx) => `<g transform="translate(${600 + dx},470) rotate(${rot})"><rect x="-120" y="-250" width="240" height="440" rx="10" fill="#ffd21f" stroke="#d9a800" stroke-width="3"/>
      <rect x="-120" y="-250" width="240" height="440" rx="10" fill="url(#sheen)"/>
      <g stroke="#e3b300" stroke-width="2" opacity=".7">${[-80, -40, 0, 40, 80].map(v => `<path d="M${v} -250V190"/>`).join('')}${[-190, -130, -70, -10, 50, 110, 160].map(v => `<path d="M-120 ${v}H120"/>`).join('')}</g>
      ${i === 3 ? `<rect x="-120" y="-250" width="240" height="40" rx="10" fill="#fff" opacity=".0"/><circle cx="0" cy="-232" r="9" fill="#fff" stroke="#d9a800" stroke-width="3"/><g fill="#3b2f10" opacity=".8">${[[-50, -120], [20, -150], [60, -60], [-30, -20], [40, 30], [-70, 60], [10, 90], [60, 130], [-40, 130]].map(([a, b]) => `<ellipse cx="${a}" cy="${b}" rx="5" ry="3.2" transform="rotate(${a * 3} ${a} ${b})"/>`).join('')}</g>` : ''}</g>`;
    return `${shadow(600, 740, 330)}${sheet(0, -18, -170)}${sheet(1, -8, -85)}${sheet(2, 2, 0)}${sheet(3, 12, 95)}
      <g transform="translate(600,730)"><rect x="-220" y="-76" width="440" height="106" rx="20" fill="#fff"/>${kora(-110, -14, 40)}${txt(70, -22, 'Yellow Sticky Traps', 28, '#13201B', 800)}${txt(70, 12, 'Pack of 20 · Weather-proof glue', 18, '#5B6A63', 500)}</g>`;
  })()),
  10: () => scene('#e3edf6', '#c1d6e8', (() => {
    const x = 560;
    return `${shadow(x + 20, 770, 250)}<g transform="translate(${x - 190},90)">
      <path d="M-60 400C-70 220 -30 120 40 120" stroke="#1d2a33" stroke-width="22" fill="none" stroke-linecap="round" opacity=".85"/>
      <path d="M0 140H320Q380 140 380 200V580Q380 650 310 650H70Q0 650 0 580V200Q0 140 0 140Z" fill="#f2b23a"/>
      <path d="M40 100H280Q330 100 330 150V160H0V150Q0 100 40 100Z" fill="#17433A"/><rect x="130" y="62" width="60" height="50" rx="10" fill="#0f2f28"/><rect x="118" y="44" width="84" height="26" rx="12" fill="#0f2f28"/>
      <path d="M0 140H320Q380 140 380 200V580Q380 650 310 650H70Q0 650 0 580V200Q0 140 0 140Z" fill="url(#sheen)"/>
      <rect x="40" y="220" width="300" height="300" rx="26" fill="#fffdf8"/>${kora(190, 285, 42)}<line x1="115" y1="304" x2="265" y2="304" stroke="#e6e0d0" stroke-width="3"/>
      ${txt(190, 385, '16 L', 80, '#17433A', 800)}${txt(190, 430, 'Battery Knapsack Sprayer', 20, '#13201B', 800)}${txt(190, 458, 'Rechargeable 12V', 17, '#5B6A63', 500)}
      <rect x="130" y="478" width="120" height="28" rx="14" fill="#17433A"/>${txt(190, 498, '6-8 hr battery', 15, '#fff', 700)}
      <rect x="330" y="420" width="76" height="140" rx="16" fill="#1d2a33"/><rect x="342" y="436" width="52" height="12" rx="6" fill="#4cd964"/><rect x="342" y="456" width="52" height="12" rx="6" fill="#4cd964"/><rect x="342" y="476" width="52" height="12" rx="6" fill="#4cd964" opacity=".35"/>
      <path d="M340 160C440 130 480 220 520 300" stroke="#1d2a33" stroke-width="14" fill="none" stroke-linecap="round"/>
      <path d="M520 300L610 560" stroke="#d9dde0" stroke-width="16" stroke-linecap="round"/><rect x="590" y="540" width="42" height="26" rx="8" transform="rotate(-20 611 553)" fill="#1d2a33"/>
      <g fill="#6fb3dd" opacity=".85">${[[640, 610, 9], [668, 640, 7], [624, 640, 6], [690, 600, 6], [656, 668, 5], [700, 640, 5], [612, 668, 5]].map(([a, b, r]) => `<circle cx="${a}" cy="${b}" r="${r}"/>`).join('')}</g></g>`;
  })()),
  11: () => scene('#e8f2e0', '#c9e2b6', (() => {
    const rings = [0, 1, 2, 3, 4, 5, 6].map(i => `<ellipse cx="360" cy="${520 + i * 4}" rx="${250 - i * 18}" ry="${95 - i * 7}" fill="none" stroke="#1d2a33" stroke-width="15" opacity="${1 - i * 0.04}"/>`).join('');
    return `${shadow(520, 775, 380)}
      <g transform="translate(180,40)">
        <g transform="translate(0,-90)">${rings}
        <ellipse cx="360" cy="548" rx="70" ry="22" fill="#e8f2e0"/>
        <path d="M610 524C760 500 820 470 860 420" stroke="#1d2a33" stroke-width="15" fill="none" stroke-linecap="round"/>
        <g fill="#2f9e44">${[[690, 500], [730, 488], [770, 470], [808, 444]].map(([a, b]) => `<rect x="${a - 8}" y="${b - 8}" width="16" height="22" rx="6"/><path d="M${a} ${b + 14}v30" stroke="#2f9e44" stroke-width="3"/><circle cx="${a}" cy="${b + 52}" r="4" fill="#2c7fb8"/>`).join('')}</g>
        <g transform="translate(560,240)"><rect x="0" y="40" width="130" height="190" rx="22" fill="#d9dde0"/><rect x="0" y="100" width="130" height="62" fill="#2c7fb8"/><rect x="-26" y="76" width="30" height="24" rx="6" fill="#1d2a33"/><rect x="126" y="76" width="30" height="24" rx="6" fill="#1d2a33"/>
          <rect x="30" y="0" width="70" height="46" rx="12" fill="#1d2a33"/><rect x="0" y="40" width="130" height="190" rx="22" fill="url(#sheen)"/>
          <g transform="translate(65,131)">${kora(0, 10, 28, '#fff')}</g></g>
        </g>
        <g transform="translate(210,640)"><rect width="360" height="92" rx="18" fill="#fff"/>${kora(70, 60, 40)}<line x1="134" y1="22" x2="134" y2="70" stroke="#e6e0d0" stroke-width="3"/>${txt(252, 44, 'Drip Irrigation Kit', 24, '#13201B', 800)}${txt(252, 70, '¼ acre · filter &amp; drippers', 17, '#5B6A63', 500)}</g>
      </g>`;
  })()),
  12: () => scene('#e7ecf8', '#c5d0ee', (() => {
    const x = 600;
    const ticks = Array.from({ length: 13 }, (_, i) => { const a = (-60 + i * 10) * Math.PI / 180; const r1 = 108, r2 = i % 2 ? 118 : 126; return `<path d="M${Math.sin(a) * r1} ${-Math.cos(a) * r1}L${Math.sin(a) * r2} ${-Math.cos(a) * r2}" stroke="#13201B" stroke-width="${i % 2 ? 3 : 5}"/>`; }).join('');
    const a = 14 * Math.PI / 180;
    return `${shadow(x, 780, 190)}<g transform="translate(${x},0)">
      <rect x="-14" y="560" width="28" height="200" rx="6" fill="#b9bfc6"/><rect x="-14" y="560" width="28" height="200" fill="url(#sheen)"/><path d="M-14 760L0 800 14 760Z" fill="#8a9099"/>
      <rect x="-26" y="620" width="52" height="14" rx="4" fill="#8a9099" opacity=".7"/>
      <path d="M-170 220Q-170 130 -80 130H80Q170 130 170 220V520Q170 580 110 580H-110Q-170 580 -170 520Z" fill="#17433A"/><path d="M-170 220Q-170 130 -80 130H80Q170 130 170 220V520Q170 580 110 580H-110Q-170 580 -170 520Z" fill="url(#sheen)"/>
      <circle cx="0" cy="300" r="140" fill="#fffdf8"/><circle cx="0" cy="300" r="140" fill="none" stroke="#0f2f28" stroke-width="8"/>
      <g transform="translate(0,360)">${ticks}
        <path d="M-96 -52A110 110 0 0 1 96 -52" fill="none" stroke="#2f7d4f" stroke-width="12" stroke-linecap="round" opacity=".28" transform="translate(0,0)"/>
        <path d="M0 0L${Math.sin(a) * 104} ${-Math.cos(a) * 104}" stroke="#d6452f" stroke-width="6" stroke-linecap="round"/><circle r="12" fill="#13201B"/></g>
      ${txt(0, 262, 'pH', 26, '#5B6A63', 700)}${txt(-92, 340, 'ACID', 13, '#d6452f', 800)}${txt(92, 340, 'ALKALI', 13, '#2c7fb8', 800)}
      ${kora(0, 500, 40, '#fff')}${txt(0, 536, 'Soil pH &amp; Moisture Meter', 18, '#cfe3d8', 600)}
      </g>`;
  })())
};

/* ------------------------------------------------------------------ preview + icons */
const iconSvg = (pad = 0, bg = true) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">${bg ? '<rect width="512" height="512" fill="#17433A"/>' : ''}<g transform="translate(256 256) scale(${1 - pad}) translate(-256 -256)"><path d="M256 96c-90 36-125 130-70 215 44 62 125 58 160-8 40-75 8-180-90-207z" fill="#A8D672"/><path d="M256 120v250M256 250l-55-50M256 305l60-55" stroke="#17433A" stroke-width="16" stroke-linecap="round" fill="none"/></g></svg>`;

(async () => {
  const dir = path.join(ROOT, 'img', 'products');
  fs.mkdirSync(dir, { recursive: true });
  fs.mkdirSync(path.join(ROOT, 'icons'), { recursive: true });
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1200, height: 900 }, deviceScaleFactor: 1 });
  const shot = async (html, file, w, h, type = 'jpeg') => {
    await page.setViewportSize({ width: w, height: h });
    await page.setContent(`<html><body style="margin:0;background:transparent">${html}</body></html>`);
    await page.screenshot({ path: file, type, ...(type === 'jpeg' ? { quality: 88 } : { omitBackground: true }), clip: { x: 0, y: 0, width: w, height: h } });
  };
  for (const [id, draw] of Object.entries(P)) {
    await shot(draw(), path.join(dir, id + '.jpg'), 1200, 900);
    const old = path.join(dir, id + '.svg'); if (fs.existsSync(old)) fs.unlinkSync(old);
  }
  /* app icons */
  await shot(iconSvg(0, true).replace('width="512" height="512"', 'width="192" height="192"'), path.join(ROOT, 'icons', 'icon-192.png'), 192, 192, 'png');
  await shot(iconSvg(0, true), path.join(ROOT, 'icons', 'icon-512.png'), 512, 512, 'png');
  await shot(iconSvg(0.22, true), path.join(ROOT, 'icons', 'maskable-512.png'), 512, 512, 'png');
  await shot(iconSvg(0.1, true).replace('width="512" height="512"', 'width="180" height="180"'), path.join(ROOT, 'icons', 'apple-touch-icon.png'), 180, 180, 'png');
  /* link preview (1200x630) with real product pictures */
  const b64 = id => 'data:image/jpeg;base64,' + fs.readFileSync(path.join(dir, id + '.jpg')).toString('base64');
  const og = `<div style="width:1200px;height:630px;position:relative;overflow:hidden;background:linear-gradient(120deg,#17433A,#2f7d4f);font-family:${FONT};color:#fff">
    <div style="position:absolute;left:70px;top:90px;width:560px">
      <div style="font:800 84px ${FONT};letter-spacing:-3px">kora<span style="color:#F2B23A">.</span><span style="font-size:26px;letter-spacing:6px;color:#A8D672;margin-left:12px">AGRO</span></div>
      <div style="font:800 52px/1.1 ${FONT};margin-top:34px">Seeds, fertilizers &amp; farm tools, delivered.</div>
      <div style="font:500 26px/1.4 ${FONT};margin-top:22px;opacity:.9">Order on WhatsApp · AI crop advice in 4 languages</div></div>
    ${[[1, 700, 70, -4], [10, 905, 150, 5], [4, 700, 330, 3], [11, 905, 400, -3]].map(([id, x, y, r]) => `<img src="${b64(id)}" style="position:absolute;left:${x}px;top:${y}px;width:260px;height:195px;object-fit:cover;border-radius:22px;border:6px solid #fff;transform:rotate(${r}deg);box-shadow:0 18px 40px rgba(0,0,0,.35)">`).join('')}
  </div>`;
  await shot(og, path.join(ROOT, 'img', 'og.png'), 1200, 630, 'png');
  await browser.close();
  for (const f of ['og.svg']) { const p = path.join(ROOT, 'img', f); if (fs.existsSync(p)) fs.unlinkSync(p); }
  console.log('Pictures written to', ROOT);
})();
