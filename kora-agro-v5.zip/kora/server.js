'use strict';
/**
 * Kora store server — zero dependencies (Node 18+).
 *   - renders the pages in /pages inside one shared layout, serves /public (PWA, images, css, js)
 *   - /api/products, /api/config, /api/order, /api/chat
 *   - /p/<id> product pages and /o/<token> order-picture pages (these give WhatsApp a link preview with images)
 *   - builds the WhatsApp order template (single source of truth for the message)
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');

/* ---------- .env (tiny loader, replaces dotenv) ---------- */
try {
  for (const line of fs.readFileSync(path.join(__dirname, '.env'), 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (m && !line.trim().startsWith('#') && !(m[1] in process.env)) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2').replace(/\s+#.*$/, '');   // quotes and trailing comments are ignored
  }
} catch { /* no .env — fine */ }

const env = process.env;
const CFG = {
  port: Number(env.PORT) || 3000,
  groqKey: env.GROQ_API_KEY && !/your_groq_key/i.test(env.GROQ_API_KEY) ? env.GROQ_API_KEY : '',
  groqModel: env.GROQ_MODEL || 'openai/gpt-oss-120b',
  groqBase: (env.GROQ_BASE_URL || 'https://api.groq.com/openai/v1').replace(/\/$/, ''),
  whatsapp: (env.WHATSAPP_NUMBER || '').replace(/\D/g, ''),     // e.g. 919876543210
  storeName: env.STORE_NAME || 'Kora',
  publicUrl: (env.PUBLIC_URL || '').replace(/\/$/, ''),
  freeAbove: env.FREE_DELIVERY_ABOVE !== undefined ? Number(env.FREE_DELIVERY_ABOVE) : 1999,
  fee: env.DELIVERY_FEE !== undefined ? Number(env.DELIVERY_FEE) : 99
};

const PUBLIC = path.join(__dirname, 'public');
const PAGES_DIR = path.join(__dirname, 'pages');
const products = JSON.parse(fs.readFileSync(path.join(__dirname, 'products.json'), 'utf8'));
const byId = new Map(products.map(p => [p.id, p]));
const BUILD = Date.now().toString(36);                       // busts the browser cache after every restart/deploy

/* ---------- pages: one layout + one small file per page ---------- */
const SITE_DESC = 'Buy certified seeds, fertilizers, crop-care and farm tools online. AI crop advisor and WhatsApp ordering.';
const PAGES = {
  '/':         { file: 'home',     nav: 'home',     title: 'Seeds, Fertilizers & Farm Tools · Kora Agro', desc: SITE_DESC },
  '/shop':     { file: 'shop',     nav: 'shop',     title: 'Shop · Kora Agro', desc: 'Browse certified seeds, organic fertilizers, crop-care products and farm tools. Free delivery above ₹1,999.' },
  '/services': { file: 'services', nav: 'services', title: 'Services · Kora Agro', desc: 'AI crop advice, input selection, soil guidance, doorstep delivery and WhatsApp support for farmers.' },
  '/about':    { file: 'about',    nav: 'about',    title: 'About us · Kora Agro', desc: 'Kora Agro makes quality farm inputs easy to find, understand and order.' },
  '/blog':     { file: 'blog',     nav: 'blog',     title: 'Farming blog · Kora Agro', desc: 'Short, practical reads on seeds, soil, irrigation and crop care.' }
};
const tpl = {};
const view = name => tpl[name] ?? (tpl[name] = fs.readFileSync(path.join(PAGES_DIR, name + '.html'), 'utf8'));
const escHtml = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function renderPage(req, { content, title, desc, nav = '', page = '', image = '/img/og.png', robots = 'index,follow', urlPath }) {
  const origin = originOf(req);
  const on = k => nav === k ? ' class="on" aria-current="page"' : '';
  const vars = {
    TITLE: escHtml(title), DESC: escHtml(desc || SITE_DESC), URL: escHtml(origin + (urlPath ?? new URL(req.url, 'http://x').pathname)),
    OG_IMAGE: escHtml(/^https?:/.test(image) ? image : origin + image), ROBOTS: robots, PAGE: escHtml(page || nav || 'page'), V: BUILD,
    CONTENT: content.replace(/\{\{CTA\}\}/g, () => view('cta')),
    'nav-home': on('home'), 'nav-shop': on('shop'), 'nav-services': on('services'), 'nav-about': on('about'), 'nav-blog': on('blog'),
    'tab-home': on('home'), 'tab-shop': on('shop')
  };
  return view('layout').replace(/\{\{([A-Za-z_-]+)\}\}/g, (m, k) => (k in vars ? vars[k] : m));
}

/* ---------- orders store ---------- */
const FILE = path.join(__dirname, 'orders.json');
let orders = [];
try { orders = JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { orders = []; }
function saveOrders() {
  const tmp = FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(orders, null, 2));
  fs.renameSync(tmp, FILE);
}

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }
const bad = msg => new HttpError(400, msg);

/* ---------- helpers ---------- */
const inr = n => '₹' + Number(n).toLocaleString('en-IN');
const clean = (s, max) => String(s ?? '').replace(/[\u0000-\u001f\u007f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, max);

function normalizePhone(raw) {
  let d = String(raw ?? '').replace(/\D/g, '');
  if (d.length === 12 && d.startsWith('91')) d = d.slice(2);
  if (d.length === 11 && d.startsWith('0')) d = d.slice(1);
  if (!/^[6-9]\d{9}$/.test(d)) throw bad('Enter a valid 10-digit mobile number.');
  return d;
}

function normalizeCart(cart) {
  if (!Array.isArray(cart)) return [];
  const m = new Map();
  for (const c of cart) {
    const id = Number(c?.id), qty = Math.floor(Number(c?.qty));
    if (!byId.has(id) || !(qty > 0)) continue;
    m.set(id, Math.min(20, (m.get(id) || 0) + qty));
  }
  return [...m].map(([id, qty]) => ({ id, qty }));
}

const lines = cart => cart.map(c => {
  const p = byId.get(c.id);
  return { id: p.id, name: p.name, qty: c.qty, price: p.price, line_total: p.price * c.qty, image: p.image };
});
const subtotal = cart => lines(cart).reduce((s, l) => s + l.line_total, 0);
const deliveryFee = sub => (sub === 0 || sub >= CFG.freeAbove ? 0 : CFG.fee);
const totals = cart => { const s = subtotal(cart), d = deliveryFee(s); return { subtotal: s, delivery: d, total: s + d }; };

function cleanLocation(l) {
  const lat = Number(l?.lat), lng = Number(l?.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  const acc = Number(l?.accuracy);
  return { lat: +lat.toFixed(6), lng: +lng.toFixed(6), accuracy: Number.isFinite(acc) ? Math.round(acc) : null };
}

function newOrderId() {
  for (let i = 0; i < 20; i++) {
    const id = 'KR' + crypto.randomInt(100000, 1000000);
    if (!orders.some(o => o.id === id)) return id;
  }
  return 'KR' + Date.now().toString().slice(-8);
}

function createOrder(cartIn, d) {
  const cart = normalizeCart(cartIn);
  if (!cart.length) throw bad('Your cart is empty.');
  const name = clean(d.name, 80);
  if (name.length < 2) throw bad('Enter your full name.');
  const phone = normalizePhone(d.phone);
  const address = clean(d.address, 400);
  if (address.length < 8) throw bad('Enter a complete delivery address.');
  const pincode = clean(d.pincode, 6);
  if (pincode && !/^\d{6}$/.test(pincode)) throw bad('Pincode must be 6 digits.');
  const payment = d.payment === 'upi' ? 'upi' : 'cod';
  const t = totals(cart);
  const order = {
    id: newOrderId(), token: crypto.randomBytes(9).toString('base64url'), name, phone, address, pincode, landmark: clean(d.landmark, 120),
    notes: clean(d.notes, 300), payment, location: cleanLocation(d.location),
    items: lines(cart), subtotal: t.subtotal, delivery: t.delivery, total: t.total,
    status: 'Confirmed', created: new Date().toISOString()
  };
  orders.push(order);
  saveOrders();
  return order;
}

/* ---------- WhatsApp order template ---------- */
function isPublicOrigin(origin) {
  try {
    const h = new URL(origin).hostname;
    return !(h === 'localhost' || /^127\./.test(h) || /^10\./.test(h) || /^192\.168\./.test(h) || /^172\.(1[6-9]|2\d|3[01])\./.test(h) || h.endsWith('.local'));
  } catch { return false; }
}

function whatsappMessage(o, origin) {
  const when = new Date(o.created).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true });
  const L = [];
  L.push(`🛒 *New order ${o.id}*`, `_${CFG.storeName} · ${when}_`, '');
  L.push(`👤 *Name:* ${o.name}`, `📞 *Phone:* +91 ${o.phone}`);
  L.push(`📍 *Deliver to:* ${o.address}${o.pincode && !o.address.includes(o.pincode) ? ' - ' + o.pincode : ''}`);
  if (o.landmark) L.push(`🏷️ *Landmark:* ${o.landmark}`);
  L.push('', '*Items*');
  o.items.forEach((i, n) => L.push(`${n + 1}. ${i.name} × ${i.qty} — ${inr(i.line_total)}`));
  /* One link, placed before any other link: WhatsApp turns the first link into a preview card with the product picture. */
  const pics = picturesUrl(o, origin);
  if (pics) L.push('', `🖼️ *Product pictures:* ${pics}`);
  L.push('', `Subtotal: ${inr(o.subtotal)}`, `Delivery: ${o.delivery ? inr(o.delivery) : 'FREE'}`, `*Total: ${inr(o.total)}*`);
  L.push(`💳 *Payment:* ${o.payment === 'upi' ? 'UPI / card (please send a pay link)' : 'Cash on delivery'}`);
  if (o.notes) L.push(`📝 *Note:* ${o.notes}`);
  if (o.location) L.push(`🗺️ *Map pin:* https://www.google.com/maps?q=${o.location.lat},${o.location.lng}`);
  L.push('', 'Please confirm this order. Thank you! 🙏');
  return L.join('\n');
}

/* Confirmation the customer keeps: sent to their own WhatsApp (wa.me/91<phone>) so they hold a copy with order id, items and total. */
function confirmationMessage(o, origin) {
  const L = [`✅ *Order confirmed — ${o.id}*`, `Thank you ${String(o.name).split(' ')[0]}! Your order with ${CFG.storeName} is received.`, '', '*Items*'];
  o.items.forEach((i, n) => L.push(`${n + 1}. ${i.name} × ${i.qty} — ${inr(i.line_total)}`));
  const pics = picturesUrl(o, origin);
  if (pics) L.push('', `🖼️ *Product pictures:* ${pics}`);
  L.push('', `*Total: ${inr(o.total)}*${o.delivery ? '' : ' (free delivery)'}`, `💳 ${o.payment === 'upi' ? 'UPI / card — we will send a pay link' : 'Cash on delivery'}`);
  L.push(`📍 ${o.address}${o.pincode && !o.address.includes(o.pincode) ? ' - ' + o.pincode : ''}`, '', `We will call or message you to confirm delivery. Store WhatsApp: +${CFG.whatsapp}`);
  return L.join('\n');
}

/* A public page that shows the order's pictures (no name, phone or address on it). Only possible on a public address. */
const picturesUrl = (o, origin) => (o.token && isPublicOrigin(origin) ? `${origin}/o/${o.token}` : null);

function withWhatsApp(o, origin) {
  const text = whatsappMessage(o, origin);
  const q = encodeURIComponent(text), n = CFG.whatsapp;
  const conf = confirmationMessage(o, origin), mine = /^\d{10}$/.test(o.phone) ? '91' + o.phone : String(o.phone).replace(/\D/g, '');
  return {
    ...o, whatsapp_text: text, confirmation_text: conf,
    customer_whatsapp_url: `https://wa.me/${mine}?text=${encodeURIComponent(conf)}`,               // the customer's own WhatsApp: a saved copy of the confirmation
    whatsapp_text_orig: undefined, store_whatsapp: n, pictures_url: picturesUrl(o, origin),
    whatsapp_url: `https://wa.me/${n}?text=${q}`,                                                  // works everywhere: opens the app on a phone, WhatsApp Web / Desktop on a computer
    whatsapp_web_url: `https://web.whatsapp.com/send?${n ? 'phone=' + n + '&' : ''}text=${q}`,    // straight into WhatsApp Web
    whatsapp_app_url: `whatsapp://send?${n ? 'phone=' + n + '&' : ''}text=${q}`                   // straight into the installed app
  };
}

function originOf(req) {
  if (CFG.publicUrl) return CFG.publicUrl;
  const proto = (req.headers['x-forwarded-proto'] || 'http').split(',')[0].trim();
  const host = (req.headers['x-forwarded-host'] || req.headers.host || 'localhost').split(',')[0].trim();
  return `${proto}://${host}`;
}

/* ---------- languages: the customer picks one in the app, Kora answers ONLY in it ---------- */
const LANGS = {
  'en-IN': { name: 'English', script: '', re: null },
  'hi-IN': { name: 'Hindi', script: 'Devanagari', re: /[\u0900-\u097F]/g },
  'te-IN': { name: 'Telugu', script: 'Telugu', re: /[\u0C00-\u0C7F]/g },
  'ml-IN': { name: 'Malayalam', script: 'Malayalam', re: /[\u0D00-\u0D7F]/g }
};
const STUCK = {
  'en-IN': 'Sorry, I got stuck on that. Could you say it again?',
  'hi-IN': 'माफ़ कीजिए, मैं अटक गई। क्या आप फिर से कह सकते हैं?',
  'te-IN': 'క్షమించండి, నాకు అర్థం కాలేదు. మళ్ళీ చెప్పగలరా?',
  'ml-IN': 'ക്ഷമിക്കണം, എനിക്ക് മനസ്സിലായില്ല. ഒന്നുകൂടി പറയാമോ?'
};
const langRule = code => {
  const L = LANGS[code];
  if (!L.script) return 'LANGUAGE RULE (highest priority): the customer chose English in the app. Write every reply in English only, even if the customer writes or speaks another language.';
  return `LANGUAGE RULE (highest priority): the customer chose ${L.name} in the app. Write every reply only in ${L.name}, in ${L.script} script (never in English letters), even if the customer writes or speaks English or another language. Do not mix languages. Product names, brand names and order ids stay exactly as in the catalog. Write numbers as digits and amounts like ₹2,999. Tool arguments always stay in English.`;
};
/* Safety net: if the model still answers in the wrong language, rewrite the reply once. */
function langOK(text, code) {
  const letters = text.match(/\p{L}/gu) || [];
  if (letters.length < 12) return true;
  const L = LANGS[code];
  if (!L.re) return letters.filter(c => !/[A-Za-z\u00C0-\u024F]/.test(c)).length / letters.length < 0.1;
  return (text.match(L.re) || []).length / letters.length > 0.4;
}
async function enforceLang(reply, code) {
  if (!reply || langOK(reply, code)) return reply;
  const L = LANGS[code];
  try {
    const d = await groq([
      { role: 'system', content: 'You rewrite text. Output only the rewritten text and nothing else.' },
      { role: 'user', content: `Rewrite this shop assistant reply entirely in ${L.name}${L.script ? ' using ' + L.script + ' script' : ''}. Keep product names, ₹ amounts, order ids and numbers unchanged. Plain text, no markdown.\n\n${reply}` }
    ], false);
    const t = d.choices?.[0]?.message?.content?.trim();
    return t && langOK(t, code) ? t : reply;
  } catch { return reply; }
}

/* ---------- AI assistant ---------- */
const TOOLS = [
  ['search_products', 'Search the catalog. Use for any product question, browsing or recommendation.', { query: { type: 'string' }, category: { type: 'string', enum: ['Seeds', 'Fertilizers', 'Crop Care', 'Farm Tools'] }, max_price: { type: 'number' }, sort: { type: 'string', enum: ['price_asc', 'price_desc'] } }, []],
  ['show_all_products', 'Show every product (or a whole category) as product cards inside the chat. Use when the customer asks to see all products, the whole catalog, everything, or a full category.', { category: { type: 'string', enum: ['Seeds', 'Fertilizers', 'Crop Care', 'Farm Tools'] }, sort: { type: 'string', enum: ['price_asc', 'price_desc'] } }, []],
  ['get_product', 'Get full details of one product by id.', { product_id: { type: 'integer' } }, ['product_id']],
  ['add_to_cart', 'Add a product to the cart by id.', { product_id: { type: 'integer' }, qty: { type: 'integer' } }, ['product_id']],
  ['update_cart_quantity', 'Set the exact quantity of a product already in the cart. 0 removes it.', { product_id: { type: 'integer' }, qty: { type: 'integer' } }, ['product_id', 'qty']],
  ['remove_from_cart', 'Remove a product from the cart by id.', { product_id: { type: 'integer' } }, ['product_id']],
  ['clear_cart', 'Empty the cart.', {}, []],
  ['show_cart', 'Show the current cart with delivery and total.', {}, []],
  ['show_order_form', 'Show the delivery form inside the chat, with the product pictures, so the customer can type name, phone and address and tap Place order. Use when the customer wants to buy, order or checkout and the cart has items.', {}, []],
  ['place_order', 'Place the order. Only call after the customer gave (or confirmed saved) name, phone and delivery address, heard the total, and clearly said yes.', { name: { type: 'string' }, phone: { type: 'string' }, address: { type: 'string' }, payment: { type: 'string', enum: ['cod', 'upi'] }, notes: { type: 'string' } }, ['name', 'phone', 'address']],
  ['track_order', 'Look up an order by its id.', { order_id: { type: 'string' } }, ['order_id']]
].map(([name, description, properties, required]) => {
  /* Models often send null for optional fields. Allow it in the schema so Groq does not reject the call. */
  const props = {};
  for (const [k, v] of Object.entries(properties)) props[k] = required.includes(k) ? v : { ...v, type: [v.type, 'null'], ...(v.enum ? { enum: [...v.enum, null] } : {}) };
  return { type: 'function', function: { name, description, parameters: { type: 'object', properties: props, required } } };
});

const cartView = st => ({ cart: lines(st.cart).map(({ id, name, qty, price, line_total }) => ({ id, name, qty, price, line_total })), ...totals(st.cart) });

function runTool(name, a, st) {
  a = Object.fromEntries(Object.entries(a || {}).filter(([, v]) => v !== null));
  const pid = Number(a.product_id);
  switch (name) {
    case 'search_products': {
      const words = String(a.query || '').toLowerCase().split(/[^a-z0-9ऀ-෿]+/).filter(w => w.length > 1);
      let r = products.filter(p => (!a.category || p.category === a.category) && (!a.max_price || p.price <= Number(a.max_price)));
      if (words.length) {
        r = r.map(p => {
          const hay = (p.name + ' ' + p.category + ' ' + p.desc + ' ' + p.kw).toLowerCase();
          return { p, s: words.reduce((s, w) => s + (hay.includes(w) ? (p.name.toLowerCase().includes(w) ? 3 : 1) : 0), 0) };
        }).filter(x => x.s > 0).sort((x, y) => y.s - x.s).map(x => x.p);
      }
      if (a.sort === 'price_asc') r = [...r].sort((x, y) => x.price - y.price);
      if (a.sort === 'price_desc') r = [...r].sort((x, y) => y.price - x.price);
      r = r.slice(0, 8);
      r.forEach(p => st.shown.includes(p.id) || st.shown.push(p.id));
      return r.map(({ id, name, category, price, desc }) => ({ id, name, category, price_inr: price, desc }));
    }
    case 'show_all_products': {
      const category = ['Seeds', 'Fertilizers', 'Crop Care', 'Farm Tools'].includes(a.category) ? a.category : 'All';
      const sort = a.sort === 'price_asc' ? 'low' : a.sort === 'price_desc' ? 'high' : 'featured';
      st.view = { category, sort };
      const list = products.filter(p => category === 'All' || p.category === category);
      const ordered = sort === 'low' ? [...list].sort((x, y) => x.price - y.price) : sort === 'high' ? [...list].sort((x, y) => y.price - x.price) : list;
      st.shown = ordered.map(p => p.id);
      return { ok: true, count: list.length, products: list.map(({ id, name, price }) => ({ id, name, price_inr: price })) };
    }
    case 'get_product': {
      const p = byId.get(pid);
      return p ? { id: p.id, name: p.name, category: p.category, price_inr: p.price, desc: p.desc, badge: p.badge || undefined } : { error: 'Product not found' };
    }
    case 'add_to_cart': {
      const p = byId.get(pid);
      if (!p) return { error: 'Product not found' };
      const n = Math.min(20, Math.max(1, Math.floor(Number(a.qty)) || 1));
      const i = st.cart.find(c => c.id === p.id);
      i ? (i.qty = Math.min(20, i.qty + n)) : st.cart.push({ id: p.id, qty: n });
      return { ok: true, ...cartView(st) };
    }
    case 'update_cart_quantity': {
      const i = st.cart.find(c => c.id === pid);
      if (!i) return { error: 'That product is not in the cart' };
      const q = Math.min(20, Math.max(0, Math.floor(Number(a.qty)) || 0));
      st.cart = q ? st.cart.map(c => c.id === pid ? { ...c, qty: q } : c) : st.cart.filter(c => c.id !== pid);
      return { ok: true, ...cartView(st) };
    }
    case 'remove_from_cart':
      st.cart = st.cart.filter(c => c.id !== pid);
      return { ok: true, ...cartView(st) };
    case 'clear_cart': st.cart = []; return { ok: true, ...cartView(st) };
    case 'show_cart': return cartView(st);
    case 'show_order_form': st.form = true; return { ok: true, note: 'The form is now shown in the chat.' };
    case 'place_order': {
      const pr = st.profile;
      st.order = createOrder(st.cart, {
        name: a.name || pr.name, phone: a.phone || pr.phone, address: a.address || pr.address,
        pincode: pr.pincode, landmark: pr.landmark, notes: a.notes, payment: a.payment,
        location: (!a.address || a.address === pr.address) ? pr.location : null
      });
      st.cart = [];
      return { ok: true, order_id: st.order.id, subtotal: st.order.subtotal, delivery: st.order.delivery, total: st.order.total };
    }
    case 'track_order': {
      const id = String(a.order_id || '').toUpperCase().replace(/\s/g, '');
      const o = orders.find(x => x.id === id);
      return o ? { id: o.id, status: o.status, total: o.total, items: o.items.map(i => i.name + ' x' + i.qty) } : { error: 'Order not found' };
    }
  }
  return { error: 'Unknown tool' };
}

const systemPrompt = (st, code) => {
  const pr = st.profile;
  const saved = pr.name || pr.phone || pr.address
    ? `Saved details on this device: name=${pr.name || 'none'}, phone=${pr.phone || 'none'}, address=${pr.address || 'none'}. Offer to use them instead of asking again.`
    : 'No saved customer details yet.';
  return `You are Kora, the friendly shopping assistant and crop advisor of ${CFG.storeName}, an online agriculture store in India selling seeds, fertilizers, crop-care products and farm tools. When a farmer describes a crop, season, soil or pest problem, give one short practical tip, then search the catalog and recommend matching products. Never promise yields and tell them to check the label or ask a local agriculture officer for serious crop diseases. Prices are in Indian rupees (₹).
Customers type or speak, and replies may be read aloud: use 1-3 short sentences, plain text, no markdown, no lists, no emojis. ${langRule(code)}
Always use tools for product facts, cart changes and orders. Never invent products, prices or order ids. When you search, the app shows product cards, so mention at most three by name with price instead of reading everything.
When the customer asks to see all products, the whole catalog, a full category, or to scroll through everything, call show_all_products (set category or sort only if they asked for it) and tell them the products are shown right here in the chat. Leave optional tool arguments out when you do not need them; never pass null.
Delivery is free above ₹${CFG.freeAbove}, otherwise ₹${CFG.fee}.
When the customer says they want to buy or order a product: confirm which product (search if unsure), add it with add_to_cart, then call show_order_form: the app shows a delivery form right here in the chat with the product pictures, so tell the customer to fill it in and tap Place order. Do not ask for name, phone or address one by one unless the customer says they prefer to speak them.
To place an order: you need name, phone number and delivery address. ${saved} Read the cart total (with delivery) back and wait for a clear yes before calling place_order. Ask cash on delivery or UPI only if the customer cares; default is cash on delivery.
After placing it, say the order id slowly and tell the customer to tap the green Send on WhatsApp button to send the order to the store.`;
};

/* Models to try, best first. If the chosen one is not enabled for this key, Kora asks Groq which models the key
   can use and picks the next good one by itself, so a wrong model name never breaks the chat. */
const MODEL_PREFERENCE = ['openai/gpt-oss-120b', 'llama-3.3-70b-versatile', 'openai/gpt-oss-20b', 'qwen/qwen3-32b', 'meta-llama/llama-4-scout-17b-16e-instruct', 'moonshotai/kimi-k2-instruct', 'llama-3.1-8b-instant'];
const NOT_CHAT = /whisper|tts|guard|orpheus|playai|embed|safeguard|distil-whisper/i;
let activeModel = CFG.groqModel;

async function availableModels() {
  try {
    const r = await fetch(CFG.groqBase + '/models', { headers: { Authorization: 'Bearer ' + CFG.groqKey }, signal: AbortSignal.timeout(12000) });
    const d = await r.json().catch(() => ({}));
    return r.ok ? (d.data || []).map(m => m.id).filter(id => !NOT_CHAT.test(id)) : [];
  } catch { return []; }
}
async function nextModel(tried) {
  const have = await availableModels();
  const pool = have.length ? [...MODEL_PREFERENCE.filter(m => have.includes(m)), ...have] : MODEL_PREFERENCE;
  return pool.find(m => !tried.has(m)) || null;
}

async function groq(messages, useTools = true) {
  const tried = new Set([activeModel]);
  let lastErr = null;
  for (let attempt = 0; attempt < 10; attempt++) {
    const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 30000);
    try {
      const body = { model: activeModel, messages, ...(useTools ? { tools: TOOLS, tool_choice: 'auto' } : {}), temperature: 0.3, max_tokens: 1500 };
      if (/gpt-oss/.test(activeModel)) body.reasoning_effort = 'low';       // only these models accept it
      let r;
      try {
        r = await fetch(CFG.groqBase + '/chat/completions', { method: 'POST', signal: ctl.signal, headers: { Authorization: 'Bearer ' + CFG.groqKey, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
      } catch (netErr) {                                // no internet, firewall, DNS, timeout
        console.error('[AI] Could not reach Groq:', netErr.cause?.code || netErr.cause?.message || netErr.message);
        lastErr = new HttpError(502, 'Kora could not reach the AI service from this computer. Check the internet connection or firewall and try again.');
        if (attempt < 3) { await new Promise(s => setTimeout(s, 500 * (attempt + 1))); continue; }
        throw lastErr;
      }
      const d = await r.json().catch(() => ({}));
      if (r.ok) return d;
      const code = d.error?.code || '', msg = d.error?.message || '';
      console.error(`[AI] Groq replied ${r.status} ${code} (model ${activeModel}): ${msg}`);
      if (r.status === 401) throw new HttpError(502, 'Groq rejected the AI key. Check GROQ_API_KEY in the .env file (or make a new key at console.groq.com/keys).');
      if (r.status === 404 || /^model_/.test(code) || /does not exist or you do not have access|decommissioned/i.test(msg)) {
        const next = await nextModel(tried);
        if (!next) throw new HttpError(502, 'No Groq chat model is enabled for this key. In console.groq.com open Settings > Limits (model permissions) and allow a chat model such as llama-3.3-70b-versatile, or create a new API key.');
        console.error(`[AI] Switching to ${next}`);
        tried.add(next); activeModel = next; continue;
      }
      if ((code === 'tool_use_failed' || r.status === 429 || r.status >= 500) && attempt < 8) { await new Promise(s => setTimeout(s, 400 * (attempt + 1))); continue; }
      throw new HttpError(r.status === 429 ? 429 : 502, r.status === 429 ? 'Kora is busy right now. Try again in a few seconds.' : (msg || 'AI service error ' + r.status));
    } finally { clearTimeout(timer); }
  }
  throw lastErr || new HttpError(502, 'The AI service did not answer. Please try again.');
}

/* Quick health check of the AI key, printed at start-up and available at /api/ai-check (never shows the key). */
let aiState = { at: 0, data: null };
async function aiCheck() {
  if (!CFG.groqKey) return { ok: false, message: 'No GROQ_API_KEY set in .env' };
  if (Date.now() - aiState.at < 30000 && aiState.data) return aiState.data;
  let data;
  try {
    const r = await fetch(CFG.groqBase + '/models', { headers: { Authorization: 'Bearer ' + CFG.groqKey }, signal: AbortSignal.timeout(12000) });
    const d = await r.json().catch(() => ({}));
    if (r.ok) { const ids = (d.data || []).map(m => m.id).filter(id => !NOT_CHAT.test(id)); data = { ok: ids.length > 0, model: ids.includes(activeModel) ? activeModel : (MODEL_PREFERENCE.find(m => ids.includes(m)) || ids[0] || null), chat_models: ids, message: ids.length ? 'Groq key accepted' : 'Key accepted but no chat model is enabled for it' }; }
    else data = { ok: false, status: r.status, message: r.status === 401 ? 'Groq rejected the key (401). Check GROQ_API_KEY.' : (d.error?.message || 'Groq answered ' + r.status) };
  } catch (e) { data = { ok: false, message: 'Cannot reach Groq from this computer: ' + (e.cause?.code || e.message) }; }
  aiState = { at: Date.now(), data };
  return data;
}

/* Product requests are detected here, so cards always appear even when the AI model answers in plain text and forgets to call a tool. */
const STOP = new Set(('show me see list display browse find search all every everything whole entire full complete catalog catalogue collection range inventory product products item items stuff things please pls plz can could would you your yours i we want need to a an the of in on for my some any what which do does have has sell is are am available give tell about under below above over within upto up rupees rupee rs inr cheap cheapest cheaper lowest highest expensive costly premium best price priced cost sorted sort by first and with from store shop buy get looking look suggest recommend option options more other another new top good nice hi hello hey kora sir bro there here it this that these those also just only like show-me').split(' '));
const CART_WORDS = /\b(add|remove|delete|clear|cart|checkout|check out|place|confirm|cancel|track|order|ordered|deliver|delivery|address|phone|number|payment|pay|cod|upi)\b/;
const TRIGGER = /\b(show|see|list|display|browse|find|search|looking|need|want|suggest|recommend|products?|items?|catalog(ue)?|collection|available|sell|have|under|below|cheap(est)?|gift|best|options?|compare|all|everything)\b/;
const TRIGGER_INDIC = /(दिखा|सभी|सारे|प्रोडक्ट|उत्पाद|सामान|అన్ని|చూపించు|చూపించండి|ప్రొడక్ట్|ప్రోడక్ట్|എല്ലാ|കാണിക്ക|ഉൽപ്പന്ന|പ്രൊഡക്റ്റ്)/;
function preSearch(text, st) {
  const raw = String(text || '').slice(0, 300), t = raw.toLowerCase();
  if (!t.trim() || CART_WORDS.test(t)) return null;
  const trigger = TRIGGER.test(t) || TRIGGER_INDIC.test(raw);
  const m = t.match(/(?:under|below|less than|within|upto|up to|max|maximum|budget|₹|rs\.?|inr)\s*(\d[\d,]*)/);
  const max = m ? Number(m[1].replace(/,/g, '')) : null;
  const sort = /\b(cheap(est)?|lowest|low to high|affordable)\b/.test(t) ? 'price_asc' : /\b(expensive|premium|highest|high to low|costly)\b/.test(t) ? 'price_desc' : null;
  const stem = w => w.replace(/(ches|shes|xes)$/, x => x.slice(0, -2)).replace(/(?<=[a-z]{3})s$/, '');
  let words = t.split(/[^a-z0-9ऀ-෿]+/).filter(w => w.length > 1 && !/^\d+$/.test(w) && !STOP.has(w)).map(stem);
  const cats = [...new Set(products.map(p => p.category))];
  /* "seeds", "fertilizer", "crop care", "farm tools" ... any word of a category name (singular or plural) selects it */
  const catTokens = c => c.toLowerCase().split(/\s+/).map(stem).filter(tk => tk.length >= 4);
  const isTok = (w, tk) => w === tk || (w.length >= 4 && w.startsWith(tk.slice(0, 6)));
  const category = cats.find(c => catTokens(c).some(tk => words.some(w => isTok(w, tk))));
  if (category) words = words.filter(w => !catTokens(category).some(tk => isTok(w, tk)));
  let name, args;
  if (!words.length) {
    if (!trigger && !category) return null;
    if (category && !max) { name = 'show_all_products'; args = { category, sort }; }
    else if (max) { name = 'search_products'; args = { query: '', category, max_price: max, sort }; }
    else { name = 'show_all_products'; args = { sort }; }
  } else { name = 'search_products'; args = { query: words.join(' '), category, max_price: max, sort }; }
  const out = runTool(name, args, st);
  if (Array.isArray(out) && !out.length) return null;
  const clean = Object.fromEntries(Object.entries(args).filter(([, v]) => v !== null && v !== ''));
  const id = 'pre_' + Date.now().toString(36);
  return [{ role: 'assistant', content: '', tool_calls: [{ id, type: 'function', function: { name, arguments: JSON.stringify(clean) } }] }, { role: 'tool', tool_call_id: id, content: JSON.stringify(out) }];
}

async function chat(body, origin) {
  if (!CFG.groqKey) throw new HttpError(503, 'The AI assistant is not set up yet. Add GROQ_API_KEY to the .env file.');
  const code = LANGS[body.lang] ? body.lang : 'en-IN';
  const pr = body.profile || {};
  const st = {
    cart: normalizeCart(body.cart), order: null, shown: [], view: null, form: false,
    profile: { name: clean(pr.name, 80), phone: clean(pr.phone, 20), address: clean(pr.address, 400), pincode: clean(pr.pincode, 6), landmark: clean(pr.landmark, 120), location: cleanLocation(pr.location) }
  };
  const history = (Array.isArray(body.messages) ? body.messages : []).slice(-14)
    .filter(m => (m.role === 'user' || m.role === 'assistant') && typeof m.content === 'string')
    .map(m => ({ role: m.role, content: m.content.slice(0, 1000) }));
  const msgs = [{ role: 'system', content: systemPrompt(st, code) }, ...history];
  const lastUser = history.length && history[history.length - 1].role === 'user' ? history[history.length - 1].content : '';
  const pre = preSearch(lastUser, st);
  if (pre) msgs.push(...pre);
  for (let i = 0; i < 6; i++) {
    const d = await groq(msgs);
    const m = d.choices?.[0]?.message;
    if (!m) throw new HttpError(502, 'Empty reply from AI service');
    if (!m.tool_calls?.length) {
      return { reply: await enforceLang(m.content || '', code), cart: st.cart, order: st.order ? withWhatsApp(st.order, origin) : null, products: st.shown, view: st.view, form: st.form, lang: code };
    }
    msgs.push({ role: 'assistant', content: m.content || '', tool_calls: m.tool_calls });
    for (const t of m.tool_calls) {
      let out;
      try { out = runTool(t.function.name, JSON.parse(t.function.arguments || '{}'), st); }
      catch (e) { out = { error: e.message }; }
      msgs.push({ role: 'tool', tool_call_id: t.id, content: JSON.stringify(out) });
    }
  }
  return { reply: STUCK[code], cart: st.cart, order: st.order ? withWhatsApp(st.order, origin) : null, products: st.shown, view: st.view, form: st.form, lang: code };
}

/* ---------- tiny http layer ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.woff2': 'font/woff2' };
const COMPRESS = new Set(['.html', '.css', '.js', '.json', '.webmanifest', '.svg']);
const gzCache = new Map();

function send(res, status, body, headers = {}) {
  const isObj = body !== null && typeof body === 'object' && !Buffer.isBuffer(body);
  res.writeHead(status, { 'Content-Type': isObj ? 'application/json; charset=utf-8' : 'text/plain; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  res.end(isObj ? JSON.stringify(body) : body);
}

function readJson(req, limit = 100 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(new HttpError(413, 'Request too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); } catch { reject(bad('Invalid JSON')); } });
    req.on('error', reject);
  });
}

const ttsCache = new Map();
const hits = new Map();
function limited(ip, max, windowMs = 60000) {
  const now = Date.now(), h = (hits.get(ip) || []).filter(t => now - t < windowMs);
  h.push(now); hits.set(ip, h);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.length || now - v[v.length - 1] > windowMs) hits.delete(k);
  return h.length > max;
}


function sendHtml(req, res, status, html, extra = {}) {
  res.writeHead(status, { 'Content-Type': MIME['.html'], 'Cache-Control': 'no-cache', ...extra });
  res.end(req.method === 'HEAD' ? undefined : html);
}
function notFound(req, res) {
  if (/\.[a-z0-9]+$/i.test(new URL(req.url, 'http://x').pathname)) return send(res, 404, 'Not found');   // missing file
  sendHtml(req, res, 404, renderPage(req, { content: view('404'), title: 'Page not found · Kora Agro', robots: 'noindex', page: '404' }));
}

/* A single product, shareable: WhatsApp shows the product picture as a preview card. */
function productPage(req, res, id) {
  const p = byId.get(Number(id));
  if (!p) return notFound(req, res);
  const content = `<section class="phero"><div class="wrap"><nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a><a href="/shop">Shop</a><span>${escHtml(p.category)}</span></nav></div></section>
<section class="wrap pp"><img class="pp-img" alt="${escHtml(p.name)}" src="${escHtml(p.image)}" width="1200" height="900">
<div class="pp-info"><span class="cat-l">${escHtml(p.category)}</span><h1>${escHtml(p.name)}</h1><p class="pp-price">${inr(p.price)}</p><p class="muted">${escHtml(p.desc)}</p>
<div class="cta"><a class="btn btn-buy" href="/shop?buy=${p.id}">Buy now</a><a class="btn btn-quiet" href="/shop?add=${p.id}">Add to cart</a></div>
<p class="muted small">Free delivery above ${inr(CFG.freeAbove)}. Order on WhatsApp.</p></div></section>{{CTA}}`;
  sendHtml(req, res, 200, renderPage(req, { content, title: `${p.name} · Kora Agro`, desc: `${p.name}, ${inr(p.price)}. ${p.desc}`, image: p.image, nav: 'shop', page: 'product', urlPath: '/p/' + p.id }));
}

/* The pictures of one order. The link is private (random token) and shows no customer details. */
function orderPage(req, res, token) {
  const o = orders.find(x => x.token && x.token === token);
  if (!o) return notFound(req, res);
  const items = o.items.map(i => `<li><img alt="${escHtml(i.name)}" src="${escHtml(i.image)}" loading="lazy" width="1200" height="900"><div><b>${escHtml(i.name)}</b><span>${i.qty} × ${inr(i.price)}</span></div><strong>${inr(i.line_total)}</strong></li>`).join('');
  const content = `<section class="phero"><div class="wrap"><nav class="crumbs" aria-label="Breadcrumb"><a href="/">Home</a><span>Order ${escHtml(o.id)}</span></nav><h1>Order ${escHtml(o.id)}</h1><p>${o.items.length} ${o.items.length === 1 ? 'product' : 'products'} · ${inr(o.total)}</p></div></section>
<section class="wrap"><ul class="op">${items}</ul><dl class="sums op-sums"><div><dt>Subtotal</dt><dd>${inr(o.subtotal)}</dd></div><div><dt>Delivery</dt><dd>${o.delivery ? inr(o.delivery) : 'Free'}</dd></div><div class="grand"><dt>Total</dt><dd>${inr(o.total)}</dd></div></dl></section>`;
  sendHtml(req, res, 200, renderPage(req, { content, title: `Order ${o.id} · ${CFG.storeName}`, desc: `${o.items.map(i => i.name + ' × ' + i.qty).join(', ')}. Total ${inr(o.total)}.`, image: o.items[0].image, robots: 'noindex,nofollow', page: 'order', urlPath: '/o/' + token }));
}

function sitemap(req, res) {
  const origin = originOf(req), urls = [...Object.keys(PAGES), ...products.map(p => '/p/' + p.id)];
  send(res, 200, `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.map(u => `  <url><loc>${origin}${u === '/' ? '/' : u}</loc></url>`).join('\n')}\n</urlset>\n`, { 'Content-Type': 'application/xml; charset=utf-8', 'Cache-Control': 'public, max-age=3600' });
}

function serveStatic(req, res, pathname) {
  let rel;
  try { rel = decodeURIComponent(pathname); } catch { return send(res, 400, 'Bad request'); }
  const file = path.normalize(path.join(PUBLIC, rel));
  if (file !== PUBLIC && !file.startsWith(PUBLIC + path.sep)) return send(res, 403, 'Forbidden');
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return notFound(req, res);
    const ext = path.extname(file).toLowerCase();
    const noCache = rel === '/sw.js' || ext === '.webmanifest';
    const headers = { 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': noCache ? 'no-cache' : 'public, max-age=3600', 'Last-Modified': st.mtime.toUTCString(), 'X-Content-Type-Options': 'nosniff' };
    if (rel === '/sw.js') headers['Service-Worker-Allowed'] = '/';
    if (req.headers['if-modified-since'] && new Date(req.headers['if-modified-since']) >= new Date(Math.floor(st.mtimeMs / 1000) * 1000)) { res.writeHead(304, headers); return res.end(); }
    const gz = COMPRESS.has(ext) && /\bgzip\b/.test(req.headers['accept-encoding'] || '');
    if (!gz) { res.writeHead(200, { ...headers, 'Content-Length': st.size }); return req.method === 'HEAD' ? res.end() : fs.createReadStream(file).pipe(res); }
    const key = file + st.mtimeMs;
    const done = buf => { res.writeHead(200, { ...headers, 'Content-Encoding': 'gzip', 'Content-Length': buf.length, Vary: 'Accept-Encoding' }); res.end(req.method === 'HEAD' ? undefined : buf); };
    if (gzCache.has(key)) return done(gzCache.get(key));
    fs.readFile(file, (e, data) => { if (e) return send(res, 500, 'Read error'); const z = zlib.gzipSync(data); gzCache.set(key, z); done(z); });
  });
}

async function handler(req, res) {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'geolocation=(self), microphone=(self), camera=()');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  if ((req.headers['x-forwarded-proto'] || '').split(',')[0].trim() === 'https') res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self' https://nominatim.openstreetmap.org https://fonts.googleapis.com https://fonts.gstatic.com; manifest-src 'self'; worker-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
  try {
    if (p.startsWith('/api/')) {
      const ip = req.socket.remoteAddress || '';
      if (req.method === 'GET' && p === '/api/tts') {                 // spoken replies for languages the device has no voice for
        if (limited(ip + 't', 90)) throw new HttpError(429, 'Too many voice requests. Wait a moment.');
        const tl = { 'en-IN': 'en', 'hi-IN': 'hi', 'te-IN': 'te', 'ml-IN': 'ml' }[url.searchParams.get('lang')];
        const q = clean(url.searchParams.get('q'), 200);
        if (!tl || !q) throw bad('Missing language or text.');
        const key = tl + '|' + q;
        let audio = ttsCache.get(key);
        if (!audio) {
          const ctl = new AbortController(), timer = setTimeout(() => ctl.abort(), 10000);
          try {
            const r = await fetch('https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=' + tl + '&q=' + encodeURIComponent(q), { signal: ctl.signal, headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36', Referer: 'https://translate.google.com/' } });
            if (!r.ok) throw new HttpError(502, 'Voice service unavailable.');
            audio = Buffer.from(await r.arrayBuffer());
          } catch (e) { throw e instanceof HttpError ? e : new HttpError(502, 'Voice service unavailable.'); }
          finally { clearTimeout(timer); }
          if (ttsCache.size >= 300) ttsCache.delete(ttsCache.keys().next().value);
          ttsCache.set(key, audio);
        }
        return send(res, 200, audio, { 'Content-Type': 'audio/mpeg', 'Cache-Control': 'public, max-age=86400' });
      }
      if (req.method === 'GET' && p === '/api/products') return send(res, 200, products, { 'Cache-Control': 'no-cache' });
      if (req.method === 'GET' && p === '/api/ai-check') return send(res, 200, await aiCheck(), { 'Cache-Control': 'no-store' });
      if (req.method === 'GET' && p === '/api/config') return send(res, 200, { storeName: CFG.storeName, whatsapp: CFG.whatsapp, freeAbove: CFG.freeAbove, fee: CFG.fee, ai: !!CFG.groqKey, langs: Object.entries(LANGS).map(([code, l]) => ({ code, name: l.name })) });
      if (req.method === 'GET' && p.startsWith('/api/order/')) {
        const o = orders.find(x => x.id === decodeURIComponent(p.slice(11)).toUpperCase());
        return o ? send(res, 200, { id: o.id, status: o.status, total: o.total, created: o.created }) : send(res, 404, { error: 'Order not found' });
      }
      if (req.method === 'POST' && p === '/api/order') {
        if (limited(ip + 'o', 10)) throw new HttpError(429, 'Too many orders. Please wait a minute.');
        const b = await readJson(req);
        return send(res, 200, withWhatsApp(createOrder(b.cart, b), originOf(req)));
      }
      if (req.method === 'POST' && p === '/api/chat') {
        if (limited(ip + 'c', 40)) throw new HttpError(429, 'Slow down a little. Try again in a moment.');
        return send(res, 200, await chat(await readJson(req), originOf(req)));
      }
      return send(res, 404, { error: 'Not found' });
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Method not allowed');
    const route = p.length > 1 ? p.replace(/\/+$/, '') : p;
    if (PAGES[route]) { const pg = PAGES[route]; return sendHtml(req, res, 200, renderPage(req, { content: view(pg.file), title: pg.title, desc: pg.desc, nav: pg.nav, urlPath: route })); }
    if (route === '/ai') { res.writeHead(302, { Location: '/?ai=1' }); return res.end(); }             // direct link to the AI advisor
    if (/^\/(index|shop|services|about|blog)\.html$/.test(route)) { res.writeHead(301, { Location: route.startsWith('/index') ? '/' : route.replace(/\.html$/, '') }); return res.end(); }
    let m;
    if ((m = route.match(/^\/p\/(\d+)$/))) return productPage(req, res, m[1]);
    if ((m = route.match(/^\/o\/([A-Za-z0-9_-]{8,40})$/))) return orderPage(req, res, m[1]);
    if (route === '/robots.txt') return send(res, 200, `User-agent: *\nDisallow: /api/\nDisallow: /o/\nSitemap: ${originOf(req)}/sitemap.xml\n`, { 'Cache-Control': 'public, max-age=3600' });
    if (route === '/sitemap.xml') return sitemap(req, res);
    return serveStatic(req, res, p);
  } catch (e) {
    const status = e.status || 500;
    if (status === 500) console.error(e);
    send(res, status, { error: status === 500 ? 'Something went wrong on our side.' : e.message });
  }
}

if (require.main === module) {
  http.createServer(handler).listen(CFG.port, () => {
    console.log(`Kora store running at http://localhost:${CFG.port}`);
    console.log(`  AI assistant : ${CFG.groqKey ? 'ready (' + CFG.groqModel + ')' : 'OFF — set GROQ_API_KEY in .env'}`);
    if (CFG.groqKey) aiCheck().then(c => console.log(`  AI check     : ${c.ok ? 'OK' + (c.model && c.model !== CFG.groqModel ? ' (will use ' + c.model + ' because ' + CFG.groqModel + ' is not enabled for this key)' : '') : 'PROBLEM - ' + c.message}`));
    console.log(`  WhatsApp     : ${CFG.whatsapp ? '+' + CFG.whatsapp : 'no WHATSAPP_NUMBER set — customers will pick a chat manually'}`);
  });
}
module.exports = { handler, createOrder, whatsappMessage, withWhatsApp };
