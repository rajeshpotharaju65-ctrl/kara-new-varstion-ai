(() => {
'use strict';

/* ---------------------------------------------------------------- helpers */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const inr = n => '₹' + Number(n).toLocaleString('en-IN');
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ic = n => `<svg class="i"><use href="#i-${n}"/></svg>`;
const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage blocked */ } },
  del(k) { try { localStorage.removeItem(k); } catch { /* ignore */ } }
};
const PAGE = document.body.dataset.page || '';
const ON_SHOP = !!$('#chips');                                   // the shop page has the filters
const slug = t => String(t).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const TOUCH = matchMedia('(pointer:coarse)').matches;           // a phone or tablet: share pictures through the share sheet

/* ------------------------------------------------------------------ state */
let P = [];
let cfg = { storeName: 'Kora', whatsapp: '', freeAbove: 1999, fee: 99, ai: true };
let cart = (store.get('kora_cart', []) || []).filter(c => c && Number.isInteger(c.id) && c.qty > 0);
let profile = store.get('kora_profile', {}) || {};
let cat = 'All', sort = 'featured', query = '';
let lastOrder = null, pdpId = 0;

const rows = () => cart.map(c => ({ p: P.find(x => x.id === c.id), qty: c.qty })).filter(r => r.p);
const sums = () => {
  const sub = rows().reduce((s, r) => s + r.p.price * r.qty, 0);
  const del = !sub || sub >= cfg.freeAbove ? 0 : cfg.fee;
  return { sub, del, tot: sub + del };
};
const qtyOf = id => cart.find(c => c.id === id)?.qty || 0;

/* ------------------------------------------------------------------ toast */
let toastT;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg; t.classList.add('on');
  clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('on'), 2600);
}

/* ----------------------------------------------------------------- layers */
const layers = [];
const scrim = $('#scrim');
function syncLayers() {
  scrim.classList.toggle('on', layers.some(l => l.id !== 'ai'));     // the assistant is full screen and needs no scrim
  document.documentElement.classList.toggle('lock', layers.length > 0);
}
function openLayer(id, { focus = true } = {}) {
  const el = document.getElementById(id);
  if (!el || layers.includes(el)) return;
  el._opener = document.activeElement;
  layers.push(el);
  el.classList.add('on'); el.setAttribute('aria-hidden', 'false');
  syncLayers();
  if (focus) setTimeout(() => (el.querySelector('[data-first]') || el.querySelector('input:not([type=radio]),textarea,button,a[href]'))?.focus({ preventScroll: true }), 60);
}
function closeLayer(el) {
  if (typeof el === 'string') el = document.getElementById(el);
  const i = layers.indexOf(el);
  if (i < 0) return;
  layers.splice(i, 1);
  el.classList.remove('on'); el.setAttribute('aria-hidden', 'true');
  syncLayers();
  el._opener?.focus?.({ preventScroll: true });
}
const closeTop = () => { const t = layers[layers.length - 1]; if (t) closeLayer(t); };
scrim.addEventListener('click', () => { const t = [...layers].reverse().find(l => l.id !== 'ai'); if (t) closeLayer(t); });
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') closeTop();
  if (e.key === 'Tab' && layers.length) {
    const top = layers[layers.length - 1];
    const f = $$('a[href],button:not([disabled]),input:not([disabled]):not([type=hidden]),textarea,select', top).filter(x => x.offsetParent !== null || x === document.activeElement);
    if (!f.length) return;
    if (!top.contains(document.activeElement)) { f[0].focus(); e.preventDefault(); return; }
    const a = f[0], z = f[f.length - 1];
    if (e.shiftKey && document.activeElement === a) { z.focus(); e.preventDefault(); }
    else if (!e.shiftKey && document.activeElement === z) { a.focus(); e.preventDefault(); }
  }
});
// sheets sit inside a full-screen flex wrapper: clicking the empty area closes
['checkoutSheet', 'ticketSheet', 'pdp'].forEach(id => $('#' + id).addEventListener('click', e => { if (e.target.id === id) closeLayer(id); }));

/* ------------------------------------------------------------------- shop */
function card(p) {
  const q = qtyOf(p.id);
  const flag = p.badge ? `<span class="flag ${p.badge === 'New' ? 'new' : ''}">${esc(p.badge)}</span>` : '';
  const action = q
    ? `<div class="stepper" role="group" aria-label="Quantity of ${esc(p.name)}"><button type="button" data-d="-1" data-id="${p.id}" aria-label="One less of ${esc(p.name)}">${ic(q === 1 ? 'trash' : 'minus')}</button><output>${q}</output><button type="button" data-d="1" data-id="${p.id}" aria-label="One more of ${esc(p.name)}">${ic('plus')}</button></div>`
    : `<button class="btn btn-dark add" type="button" data-add="${p.id}" aria-label="Add ${esc(p.name)} to cart">${ic('plus')}Add</button>`;
  return `<article class="card"><button class="im" type="button" data-qv="${p.id}" aria-label="View details of ${esc(p.name)}"><img loading="lazy" decoding="async" width="1200" height="900" alt="${esc(p.name)}" src="${esc(p.image)}">${flag}</button>
  <div class="tx"><span class="cat-l">${esc(p.category)}</span><h3><button type="button" data-qv="${p.id}">${esc(p.name)}</button></h3><p class="d">${esc(p.desc)}</p>
  <div class="row"><span class="price">${inr(p.price)}</span>${action}</div><button class="btn btn-buy" type="button" data-buy="${p.id}">${ic('bag')}Buy now</button></div></article>`;
}

function visible() {
  const q = query.trim().toLowerCase();
  let list = P.filter(p => (cat === 'All' || p.category === cat) && (!q || q.split(/\s+/).every(w => (p.name + ' ' + p.category + ' ' + p.desc + ' ' + p.kw).toLowerCase().includes(w))));
  if (sort === 'low') list = [...list].sort((a, b) => a.price - b.price);
  if (sort === 'high') list = [...list].sort((a, b) => b.price - a.price);
  if (sort === 'name') list = [...list].sort((a, b) => a.name.localeCompare(b.name));
  return list;
}

function renderShop() {
  const grid = $('#grid'); if (!grid) return;
  const limit = Number(grid.dataset.limit) || 0;
  if (limit) {                                                  // home page: a short "popular" list
    const pop = [...P.filter(p => p.badge), ...P.filter(p => !p.badge)].slice(0, limit);
    grid.innerHTML = pop.map(card).join('');
    return;
  }
  const cats = ['All', ...new Set(P.map(p => p.category))];
  $('#chips').innerHTML = cats.map(c => `<button type="button" data-chip="${esc(c)}" aria-pressed="${c === cat}">${esc(c)}</button>`).join('');
  const list = visible();
  grid.innerHTML = list.map(card).join('');
  $('#noResults').hidden = list.length > 0;
  grid.hidden = !list.length;
  $('#count').textContent = list.length === P.length ? `${P.length} products` : `${list.length} of ${P.length} products`;
}

function renderCats() {
  const box = $('#cats'); if (!box) return;
  const cats = [...new Set(P.map(p => p.category))];
  box.innerHTML = cats.map(c => {
    const items = P.filter(p => p.category === c);
    return `<button class="cat" type="button" data-cat="${esc(c)}" aria-label="${esc(c)}, ${items.length} products"><img loading="lazy" alt="" src="${esc(items[0].image)}"><span><b>${esc(c)}</b><small>${items.length} products</small></span></button>`;
  }).join('');
}

/* product details sheet */
function renderPdp() {
  const p = P.find(x => x.id === pdpId), box = $('#pdp'); if (!p) return;
  const q = qtyOf(p.id), url = `${location.origin}/p/${p.id}`;
  const act = q
    ? `<div class="stepper" role="group" aria-label="Quantity"><button type="button" data-d="-1" data-id="${p.id}" aria-label="One less">${ic(q === 1 ? 'trash' : 'minus')}</button><output>${q}</output><button type="button" data-d="1" data-id="${p.id}" aria-label="One more">${ic('plus')}</button></div>`
    : `<button class="btn btn-dark" type="button" data-add="${p.id}">${ic('plus')}Add to cart</button>`;
  box.innerHTML = `<div class="card-s wide-s"><button class="x pdp-close" data-close type="button" aria-label="Close">${ic('x')}</button><div class="pdp">
    <div class="pdp-img"><img alt="${esc(p.name)}" src="${esc(p.image)}" width="1200" height="900">${p.badge ? `<span class="flag${p.badge === 'New' ? ' new' : ''}">${esc(p.badge)}</span>` : ''}</div>
    <div class="pdp-body"><span class="cat-l">${esc(p.category)}</span><h2>${esc(p.name)}</h2><div class="pdp-price">${inr(p.price)}</div><p class="muted">${esc(p.desc)}</p>
      <div class="pdp-acts">${act}<button class="btn btn-buy" type="button" data-buy="${p.id}">${ic('bag')}Buy now</button></div>
      <ul class="pdp-perks"><li>${ic('truck')}Free delivery above ${inr(cfg.freeAbove)}</li><li>${ic('whatsapp')}Order and support on WhatsApp</li></ul>
      <div class="pdp-share"><button class="btn btn-quiet" type="button" data-copylink="${esc(url)}">${ic('copy')}Copy link</button><a class="btn btn-quiet" target="_blank" rel="noopener" href="https://wa.me/?text=${encodeURIComponent(p.name + ' · ' + inr(p.price) + '\n' + url)}">${ic('share')}Share on WhatsApp</a></div>
    </div></div></div>`;
}
function openPdp(id) { pdpId = id; renderPdp(); openLayer('pdp', { focus: false }); setTimeout(() => $('#pdp .pdp-close')?.focus({ preventScroll: true }), 60); }

/* ------------------------------------------------------------------- cart */
function setCart(c) {
  cart = c.filter(x => x.qty > 0);
  store.set('kora_cart', cart);
  renderCart(); renderShop(); paintChatCards();
  if (pdpId && layers.includes($('#pdp'))) renderPdp();
}
function change(id, d) {
  const c = cart.map(x => ({ ...x })), i = c.find(x => x.id === id);
  if (i) i.qty = Math.min(20, i.qty + d); else if (d > 0) c.push({ id, qty: d });
  setCart(c);
}
function renderCart() {
  const n = cart.reduce((s, c) => s + c.qty, 0);
  for (const b of [$('#cc'), $('#cc2')]) { b.textContent = n; b.hidden = !n; }
  const r = rows(), s = sums();
  $('#items').innerHTML = r.length ? r.map(({ p, qty }) => `<div class="it"><img alt="" src="${esc(p.image)}"><div><b>${esc(p.name)}</b><small>${inr(p.price)} each</small></div>
    <div class="stepper"><button type="button" data-d="-1" data-id="${p.id}" aria-label="One less of ${esc(p.name)}">${ic(qty === 1 ? 'trash' : 'minus')}</button><output>${qty}</output><button type="button" data-d="1" data-id="${p.id}" aria-label="One more of ${esc(p.name)}">${ic('plus')}</button></div></div>`).join('')
    : `<div class="empty">${ic('bag').replace('class="i"', 'class="i big"')}<b>Your cart is empty</b><span class="muted">Pick something from the shop or ask Kora.</span><a class="btn btn-dark" href="/shop">Browse products</a></div>`;
  $('#subT').textContent = inr(s.sub);
  $('#delT').textContent = s.del ? inr(s.del) : (s.sub ? 'Free' : '—');
  $('#tot').textContent = inr(s.tot);
  $('#checkout').disabled = !r.length;
  const left = cfg.freeAbove - s.sub;
  $('#shipTxt').textContent = !s.sub ? `Free delivery on orders above ${inr(cfg.freeAbove)}` : left > 0 ? `Add ${inr(left)} more for free delivery` : 'You have unlocked free delivery';
  $('#shipBar').style.width = Math.min(100, (s.sub / cfg.freeAbove) * 100) + '%';
}

/* --------------------------------------------------------------- location */
class LocErr extends Error {}
function getPosition() {
  return new Promise((res, rej) => {
    if (!window.isSecureContext) return rej(new LocErr('Location needs a secure (https) connection.'));
    if (!('geolocation' in navigator)) return rej(new LocErr('This browser cannot share your location. Type your address instead.'));
    navigator.geolocation.getCurrentPosition(res, e => rej(new LocErr(
      e.code === 1 ? 'Location is blocked. Tap the lock icon next to the address, allow Location, then try again.'
        : e.code === 3 ? 'Finding you took too long. Move near a window and try again.'
          : 'Could not find your location. Check that GPS is on and try again.')),
    { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 });
  });
}
async function reverse(lat, lng) {
  const ctl = new AbortController(), t = setTimeout(() => ctl.abort(), 9000);
  try {
    const r = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&addressdetails=1&zoom=18&lat=${lat}&lon=${lng}`, { signal: ctl.signal, headers: { 'Accept-Language': 'en' } });
    if (!r.ok) throw new Error('geocode ' + r.status);
    const a = (await r.json()).address || {};
    const city = a.city || a.town || a.village || a.suburb || a.county || a.state_district || '';
    const parts = [a.house_number, a.building, a.road || a.pedestrian || a.footway, a.neighbourhood || a.quarter, a.suburb, city, a.state].filter(Boolean);
    return { address: [...new Set(parts)].join(', '), pincode: String(a.postcode || '').replace(/\D/g, '').slice(0, 6), city };
  } finally { clearTimeout(t); }
}
async function detectLocation() {
  const pos = await getPosition();
  const { latitude: lat, longitude: lng, accuracy } = pos.coords;
  let g = null;
  try { g = await reverse(lat, lng); } catch { /* offline or blocked: keep the pin only */ }
  profile = { ...profile, location: { lat: +lat.toFixed(6), lng: +lng.toFixed(6), accuracy: Math.round(accuracy) } };
  if (g?.address) { profile.address = g.address; profile.pincode = g.pincode || profile.pincode || ''; profile.city = g.city || ''; }
  store.set('kora_profile', profile);
  renderLoc();
  return { found: !!g?.address, accuracy };
}
function renderLoc() {
  const txt = profile.city ? (profile.pincode ? `${profile.city} ${profile.pincode}` : profile.city) : profile.location ? 'Pinned on map' : 'Set location';
  $('#locTxt').textContent = txt;
  $('#locBtn').classList.toggle('set', !!profile.location);
}
let locBusy = false;
async function onLocClick(btn) {
  if (locBusy) return;
  locBusy = true; btn?.classList.add('busy');
  toast('Finding your location…');
  try {
    const r = await detectLocation();
    toast(r.found ? 'Delivery location updated' : 'Got your map pin. Type the street address at checkout.');
  } catch (e) { toast(e.message || 'Could not get your location.'); }
  locBusy = false; btn?.classList.remove('busy');
}

/* --------------------------------------------------------------- checkout */
const form = $('#form');
const F = n => form.elements[n];
function fmtPhone(v) { const d = String(v).replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, ''); return d.length === 10 ? d.slice(0, 5) + ' ' + d.slice(5) : v; }
function prefill() {
  for (const k of ['name', 'phone', 'address', 'pincode', 'landmark']) if (!F(k).value && profile[k]) F(k).value = k === 'phone' ? fmtPhone(profile[k]) : profile[k];
  const s = sums();
  $('[data-sub]').textContent = inr(s.sub); $('[data-del]').textContent = s.del ? inr(s.del) : 'Free'; $('[data-tot]').textContent = inr(s.tot);
  const ls = $('#locStatus'), lb = $('#useLoc');
  lb.className = 'locate';
  ls.textContent = profile.location ? 'Map pin saved. Tap to refresh it.' : 'Fills in your address and adds a map pin';
  if (profile.location) lb.classList.add('ok');
  $('#formErr').hidden = true;
}
function openCheckout() {
  if (!cart.length) return toast('Your cart is empty');
  closeLayer('drawer'); prefill(); openLayer('checkoutSheet');
}
function buyNow(id) {                                  // one tap: put it in the cart and go straight to checkout
  if (!qtyOf(id)) change(id, 1);
  closeLayer('pdp');
  if (layers.includes($('#ai'))) { orderForm(); return; }   // inside the assistant: fill the form in the chat
  openCheckout();
}
function fieldErr(name, msg) {
  const f = F(name).closest('.f');
  f.classList.toggle('bad', !!msg);
  const e = $('.err', f); if (e) e.textContent = msg || '';
  return !msg;
}
function validate() {
  const phone = String(F('phone').value).replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, '');
  const checks = [
    fieldErr('name', F('name').value.trim().length < 2 ? 'Enter your full name' : ''),
    fieldErr('phone', /^[6-9]\d{9}$/.test(phone) ? '' : 'Enter a 10-digit mobile number'),
    fieldErr('address', F('address').value.trim().length < 8 ? 'Enter your full delivery address' : ''),
    fieldErr('pincode', /^(\d{6})?$/.test(F('pincode').value.trim()) ? '' : 'Pincode has 6 digits')
  ];
  if (checks.includes(false)) { form.querySelector('.bad input,.bad textarea')?.focus(); return false; }
  return true;
}
form.addEventListener('input', e => e.target.closest('.f')?.classList.remove('bad'));
F('phone').addEventListener('blur', e => { e.target.value = fmtPhone(e.target.value); });
$('#useLoc').addEventListener('click', async () => {
  const b = $('#useLoc'), s = $('#locStatus');
  if (b.classList.contains('busy')) return;
  b.className = 'locate busy'; s.textContent = 'Asking your device for its location…';
  try {
    const r = await detectLocation();
    if (r.found) { F('address').value = profile.address; if (profile.pincode) F('pincode').value = profile.pincode; fieldErr('address', ''); fieldErr('pincode', ''); }
    b.className = 'locate ok';
    s.textContent = r.found ? `Address filled in (accurate to about ${r.accuracy} m). Please check it.` : 'Map pin saved, but the street address could not be found. Type it below.';
  } catch (e) { b.className = 'locate fail'; s.textContent = e.message; }
});
$('#forget').addEventListener('click', () => {
  store.del('kora_profile'); profile = {}; form.reset(); renderLoc(); prefill(); toast('Saved details cleared');
});
form.addEventListener('submit', async e => {
  e.preventDefault();
  if (!validate()) return;
  const btn = $('#placeBtn'), label = $('span', btn);
  btn.disabled = true; label.textContent = 'Placing your order…'; $('#formErr').hidden = true;
  const v = Object.fromEntries(new FormData(form));
  try {
    const r = await fetch('/api/order', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ cart, ...v, phone: v.phone.replace(/\D/g, ''), location: profile.location || null }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || 'Could not place the order. Please try again.');
    profile = { ...profile, name: v.name.trim(), phone: v.phone.replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, ''), address: v.address.trim(), pincode: v.pincode.trim(), landmark: v.landmark.trim() };
    store.set('kora_profile', profile);
    setCart([]); closeLayer('checkoutSheet'); form.elements.notes.value = '';
    showTicket(d, { auto: true });
  } catch (err) {
    const fe = $('#formErr'); fe.textContent = navigator.onLine ? err.message : 'You are offline. Connect to the internet and try again.'; fe.hidden = false;
  }
  btn.disabled = false; label.textContent = 'Place order';
});

/* ----------------------------------------------------------------- ticket */
const storeNo = () => cfg.whatsapp ? '+' + cfg.whatsapp.replace(/^(\d{2})(\d{5})(\d{5})$/, '$1 $2 $3') : '';
function showTicket(o, { auto = false } = {}) {
  lastOrder = o;
  prepareCard(o);                                       // draw the order picture now so sharing is instant on tap
  const first = (o.name || '').split(' ')[0];
  $('#tkLead').textContent = `✓ Thank you${first ? ', ' + first : ''}! Order ${o.id} is confirmed.`;
  $('#ticket').innerHTML = `
    <div class="tk-top"><b>${esc(o.id)}</b><span>${new Date(o.created).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}</span></div>
    <ul class="tk-items">${o.items.map(i => `<li><img alt="" src="${esc(i.image)}"><div>${esc(i.name)}<small>${i.qty} × ${inr(i.price)}</small></div><b>${inr(i.line_total)}</b></li>`).join('')}</ul>
    <dl class="sums"><div><dt>Subtotal</dt><dd>${inr(o.subtotal)}</dd></div><div><dt>Delivery</dt><dd>${o.delivery ? inr(o.delivery) : 'Free'}</dd></div><div class="grand"><dt>Total</dt><dd>${inr(o.total)}</dd></div></dl>
    <div class="tk-meta"><span><b>${esc(o.name)}</b> · +91 ${esc(o.phone)}</span><span>${esc(o.address)}${o.pincode && !o.address.includes(o.pincode) ? ' - ' + esc(o.pincode) : ''}</span>
    ${o.location ? `<span><a href="https://www.google.com/maps?q=${o.location.lat},${o.location.lng}" target="_blank" rel="noopener">View map pin</a></span>` : ''}
    <span>${o.payment === 'upi' ? 'Pay by UPI or card (link on WhatsApp)' : 'Cash on delivery'}</span></div>`;
  $('#waSend').href = o.whatsapp_url;                   // plain link if scripts are blocked; the click is handled by shareOrder below
  $('#waText').href = o.whatsapp_url;
  $('#waMine').href = o.customer_whatsapp_url || '#'; $('#waMine').hidden = !o.customer_whatsapp_url;
  $('#tkHelp').textContent = TOUCH
    ? `Tap the green button, choose WhatsApp and the store chat${storeNo() ? ' (' + storeNo() + ')' : ''}. Your order picture and product photos go with the message.`
    : 'On a computer the order picture is copied and WhatsApp Web opens with your message. Press Ctrl+V in the chat to add the picture, then send.';
  closeLayer('drawer');
  openLayer('ticketSheet', { focus: false });
}

const loadImg = src => new Promise(res => { const i = new Image(); i.onload = () => res(i); i.onerror = () => res(null); i.src = src; });
function wrap(ctx, text, maxW) {
  const out = []; let line = '';
  for (const w of String(text).split(/\s+/)) {
    const t = line ? line + ' ' + w : w;
    if (ctx.measureText(t).width > maxW && line) { out.push(line); line = w; } else line = t;
  }
  if (line) out.push(line);
  return out;
}
async function orderCard(o) {
  await document.fonts?.ready;
  const W = 720, pad = 40, S = 2, imgs = await Promise.all(o.items.map(i => loadImg(i.image)));
  const probe = document.createElement('canvas').getContext('2d');
  probe.font = '500 24px "DM Sans", sans-serif';
  const addr = wrap(probe, o.address + (o.pincode && !o.address.includes(o.pincode) ? ' - ' + o.pincode : ''), W - pad * 2 - 44);
  const H = 130 + o.items.length * 144 + 150 + 96 + addr.length * 32 + (o.location ? 34 : 0) + 40;
  const c = document.createElement('canvas'); c.width = W * S; c.height = H * S;
  const x = c.getContext('2d'); x.scale(S, S);
  const rr = (X, Y, w, h, r) => { x.beginPath(); x.roundRect(X, Y, w, h, r); };
  x.fillStyle = '#F3F6F4'; x.fillRect(0, 0, W, H);
  x.fillStyle = '#17433A'; x.fillRect(0, 0, W, 112);
  x.fillStyle = '#fff'; x.font = '800 44px "Bricolage Grotesque", "DM Sans", sans-serif'; x.fillText('kora', pad, 70);
  x.fillStyle = '#F2B23A'; x.fillText('.', pad + x.measureText('kora').width, 70);
  x.textAlign = 'right'; x.fillStyle = '#fff'; x.font = '700 28px "DM Sans", sans-serif'; x.fillText('Order ' + o.id, W - pad, 58);
  x.fillStyle = '#BFD6CB'; x.font = '400 20px "DM Sans", sans-serif';
  x.fillText(new Date(o.created).toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' }), W - pad, 90);
  x.textAlign = 'left';
  let y = 142;
  o.items.forEach((it, n) => {
    x.save(); rr(pad, y, 160, 120, 14); x.clip(); x.fillStyle = '#dfe8e3'; x.fillRect(pad, y, 160, 120); if (imgs[n]) x.drawImage(imgs[n], pad, y, 160, 120); x.restore();   // pictures are 4:3, same as this box
    x.fillStyle = '#13201B'; x.font = '700 24px "DM Sans", sans-serif';
    const nm = wrap(x, it.name, 330).slice(0, 2), top = y + (nm.length > 1 ? 38 : 48);       // long names use two lines
    nm.forEach((l, k) => x.fillText(l, pad + 184, top + k * 30));
    x.fillStyle = '#5B6A63'; x.font = '400 21px "DM Sans", sans-serif'; x.fillText(`${it.qty} × ${inr(it.price)}`, pad + 184, top + nm.length * 30 + 4);
    x.textAlign = 'right'; x.fillStyle = '#13201B'; x.font = '700 24px "DM Sans", sans-serif'; x.fillText(inr(it.line_total), W - pad, y + 66); x.textAlign = 'left';
    y += 144;
  });
  x.setLineDash([8, 8]); x.strokeStyle = '#B9C7C0'; x.lineWidth = 2; x.beginPath(); x.moveTo(pad, y); x.lineTo(W - pad, y); x.stroke(); x.setLineDash([]);
  y += 40; x.font = '400 23px "DM Sans", sans-serif';
  const line = (l, r, b) => { x.fillStyle = b ? '#13201B' : '#5B6A63'; x.font = (b ? '800 32px "Bricolage Grotesque", "DM Sans"' : '400 23px "DM Sans"') + ', sans-serif'; x.textAlign = 'left'; x.fillText(l, pad, y); x.textAlign = 'right'; x.fillText(r, W - pad, y); y += b ? 0 : 38; };
  line('Subtotal', inr(o.subtotal)); line('Delivery', o.delivery ? inr(o.delivery) : 'Free'); y += 6; line('Total', inr(o.total), true);
  y += 24; x.textAlign = 'left';
  rr(pad, y, W - pad * 2, 52 + 32 + addr.length * 32 + (o.location ? 34 : 0), 16); x.fillStyle = '#fff'; x.fill();
  y += 40; x.fillStyle = '#13201B'; x.font = '700 24px "DM Sans", sans-serif'; x.fillText(`${o.name} · +91 ${o.phone}`, pad + 22, y);
  x.fillStyle = '#5B6A63'; x.font = '500 24px "DM Sans", sans-serif';
  addr.forEach((l, i) => x.fillText(l, pad + 22, y + 36 + i * 32));
  if (o.location) { x.fillStyle = '#1E4D3E'; x.font = '400 21px "DM Sans", sans-serif'; x.fillText(`Map pin: ${o.location.lat}, ${o.location.lng}`, pad + 22, y + 36 + addr.length * 32 + 6); }
  return new Promise(res => c.toBlob(res, 'image/png'));
}

/* ---- order picture (one image with every product, name, quantity, total and address) ---- */
const prepareCard = o => { if (!o._card) o._card = orderCard(o).catch(() => null); return o._card; };
const fileFrom = (blob, name) => new File([blob], name, { type: blob.type || 'image/jpeg' });
async function productFiles(o) {                         // the real product pictures, so WhatsApp receives them as photos
  const out = await Promise.all(o.items.slice(0, 8).map(async i => {
    try { const r = await fetch(i.image); if (!r.ok) return null; const b = await r.blob(); return fileFrom(b, slug(i.name) + (b.type === 'image/png' ? '.png' : '.jpg')); }
    catch { return null; }
  }));
  return out.filter(Boolean);
}
async function copyImage(blob) {
  try { await navigator.clipboard.write([new ClipboardItem({ [blob.type]: blob })]); return true; } catch { return false; }
}
function download(blob, name) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
}
/* Phone / app:  share sheet with the order picture + product photos, pick WhatsApp.
   Computer / web: copy the order picture, open WhatsApp Web with the message, paste with Ctrl+V. */
async function shareOrder(o) {
  if (!o) return;
  const canShare = TOUCH && !!navigator.share && !!navigator.canShare;
  /* Open the WhatsApp tab right now (inside the tap), so pop-up blockers allow it; fill in the address after the picture is ready. */
  const win = canShare ? null : window.open('about:blank', '_blank');
  const target = TOUCH ? o.whatsapp_url : (o.whatsapp_web_url || o.whatsapp_url);
  const go = () => { if (win && !win.closed) win.location.href = target; else window.open(target, '_blank'); };
  try {
    const blob = await prepareCard(o);
    if (!blob) throw new Error('card');
    const card = fileFrom(blob, `kora-order-${o.id}.png`);
    if (canShare) {
      const photos = await productFiles(o);
      for (const files of [[card, ...photos], [card]]) {
        if (navigator.canShare({ files })) { await navigator.share({ files, text: o.whatsapp_text, title: 'Order ' + o.id }); return; }
      }
    }
    const copied = await copyImage(blob);
    if (!copied) download(blob, card.name);
    go();
    toast(copied ? 'Order picture copied. In WhatsApp press Ctrl+V to attach it, then send.' : 'Order picture saved. Attach it in the WhatsApp chat.');
  } catch (err) {
    if (err.name === 'AbortError') return;                // the person closed the share menu
    go();                                                 // fall back to the plain text message
    toast('Opened WhatsApp with the order text.');
  }
}
/* The main green button sends the order WITH the pictures. */
const sendWithPictures = async (e, btn) => { e.preventDefault(); if (btn.dataset.busy) return; btn.dataset.busy = 1; btn.classList.add('is-busy'); await shareOrder(lastOrder); delete btn.dataset.busy; btn.classList.remove('is-busy'); };
$('#waSend').addEventListener('click', e => sendWithPictures(e, e.currentTarget));
$('#copyOrder').addEventListener('click', async () => {
  if (!lastOrder) return;
  try { await navigator.clipboard.writeText(lastOrder.whatsapp_text); }
  catch { const t = document.createElement('textarea'); t.value = lastOrder.whatsapp_text; document.body.append(t); t.select(); document.execCommand('copy'); t.remove(); }
  toast('Order copied. Paste it into any chat.');
});

/* ---------------------------------------------------------------- banners */
(() => {
  const el = $('#slides'); if (!el) return;
  const n = el.children.length, dots = $('#dots');
  let cur = 0, timer = null, stopped = reduceMotion;
  dots.innerHTML = [...el.children].map((_, i) => `<button type="button" role="tab" aria-label="Banner ${i + 1}" aria-selected="${i === 0}"></button>`).join('');
  const go = i => { cur = (i + n) % n; el.scrollTo({ left: cur * el.clientWidth, behavior: reduceMotion ? 'auto' : 'smooth' }); };
  const mark = () => $$('button', dots).forEach((b, i) => b.setAttribute('aria-selected', i === cur));
  el.addEventListener('scroll', () => { const i = Math.round(el.scrollLeft / el.clientWidth); if (i !== cur) { cur = i; mark(); } }, { passive: true });
  dots.addEventListener('click', e => { const i = $$('button', dots).indexOf(e.target.closest('button')); if (i > -1) { stop(); go(i); } });
  $('#prev').onclick = () => { stop(); go(cur - 1); }; $('#next').onclick = () => { stop(); go(cur + 1); };
  el.addEventListener('keydown', e => { if (e.key === 'ArrowRight') { stop(); go(cur + 1); } if (e.key === 'ArrowLeft') { stop(); go(cur - 1); } });
  const stop = () => { stopped = true; clearInterval(timer); };
  ['pointerdown', 'touchstart', 'focusin'].forEach(ev => el.addEventListener(ev, stop, { passive: true }));
  if (!stopped) timer = setInterval(() => { if (!document.hidden && !stopped) go(cur + 1); }, 7000);
  addEventListener('resize', () => { el.scrollLeft = cur * el.clientWidth; });
})();

/* -------------------------------------------------------------- assistant */
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
const log = $('#log');
let hist = [], busy = false, listening = false, rec = null, heard = '';
let voiceOn = store.get('kora_voice', true);

/* Languages. Kora listens, writes and speaks ONLY in the one picked here.
   To add another language: add an entry below and the same code to LANGS in server.js. */
const LANGS = {
  'en-IN': { label: 'English', rs: 'rupees', t: {
    greet: 'Hi, I am Kora. I can find seeds, fertilizers and farm tools, suggest what suits your crop, and get your order ready for WhatsApp. What are you looking for?',
    set: 'Okay, I will speak English from now on.', tap: 'Tap the mic or type', type: 'Type your message', listen: 'Listening…', think: 'Thinking…', speak: 'Speaking…',
    novoice: 'This device has no English voice installed, so replies will show as text only.', noheard: 'I did not hear anything. Try again.', blocked: 'Microphone blocked. Allow it in the address bar.',
    err: 'Could not hear you. Try again.', nosr: 'Voice input works in Chrome on Android and desktop. You can still type to Kora.', busy: 'Kora is busy right now. Try again in a few seconds.', fail: 'Something went wrong. Please try again.' } },
  'hi-IN': { label: 'हिन्दी · Hindi', rs: 'रुपये', t: {
    greet: 'नमस्ते, मैं कोरा हूँ, आपकी शॉपिंग सहायक। मैं प्रोडक्ट खोज सकती हूँ, कार्ट भर सकती हूँ और आपका ऑर्डर व्हाट्सऐप के लिए तैयार कर सकती हूँ। आप क्या खोज रहे हैं?',
    set: 'ठीक है, अब मैं हिंदी में बात करूँगी।', tap: 'माइक दबाएँ या टाइप करें', type: 'अपना संदेश लिखें', listen: 'सुन रही हूँ…', think: 'सोच रही हूँ…', speak: 'बोल रही हूँ…',
    novoice: 'इस डिवाइस में हिंदी आवाज़ इंस्टॉल नहीं है, इसलिए जवाब सिर्फ़ लिखे हुए दिखेंगे।', noheard: 'मुझे कुछ सुनाई नहीं दिया। फिर कोशिश करें।', blocked: 'माइक्रोफ़ोन बंद है। एड्रेस बार में इसे अनुमति दें।',
    err: 'आपकी आवाज़ सुनाई नहीं दी। फिर कोशिश करें।', nosr: 'आवाज़ से बोलना Android और डेस्कटॉप के Chrome में काम करता है। आप टाइप भी कर सकते हैं।', busy: 'कोरा अभी व्यस्त है। कुछ सेकंड बाद फिर कोशिश करें।', fail: 'कुछ गड़बड़ हो गई। कृपया फिर कोशिश करें।' } },
  'te-IN': { label: 'తెలుగు · Telugu', rs: 'రూపాయలు', t: {
    greet: 'నమస్కారం, నేను కోరా, మీ షాపింగ్ అసిస్టెంట్‌ని. ఉత్పత్తులను వెతకడం, కార్ట్ నింపడం, మీ ఆర్డర్‌ను వాట్సాప్‌కు సిద్ధం చేయడంలో సహాయం చేస్తాను. మీరు ఏమి వెతుకుతున్నారు?',
    set: 'సరే, ఇప్పటి నుండి తెలుగులో మాట్లాడతాను.', tap: 'మైక్ నొక్కండి లేదా టైప్ చేయండి', type: 'మీ సందేశం టైప్ చేయండి', listen: 'వింటున్నాను…', think: 'ఆలోచిస్తున్నాను…', speak: 'మాట్లాడుతున్నాను…',
    novoice: 'ఈ పరికరంలో తెలుగు వాయిస్ ఇన్‌స్టాల్ కాలేదు, కాబట్టి సమాధానాలు టెక్స్ట్‌గా మాత్రమే కనిపిస్తాయి.', noheard: 'నాకు ఏమీ వినిపించలేదు. మళ్ళీ ప్రయత్నించండి.', blocked: 'మైక్రోఫోన్ బ్లాక్ అయింది. అడ్రస్ బార్‌లో అనుమతించండి.',
    err: 'మీ మాట వినిపించలేదు. మళ్ళీ ప్రయత్నించండి.', nosr: 'వాయిస్ ఇన్‌పుట్ Android మరియు డెస్క్‌టాప్ Chrome‌లో పనిచేస్తుంది. మీరు టైప్ కూడా చేయవచ్చు.', busy: 'కోరా ఇప్పుడు బిజీగా ఉంది. కొన్ని సెకన్ల తర్వాత మళ్ళీ ప్రయత్నించండి.', fail: 'ఏదో తప్పు జరిగింది. దయచేసి మళ్ళీ ప్రయత్నించండి.' } },
  'ml-IN': { label: 'മലയാളം · Malayalam', rs: 'രൂപ', t: {
    greet: 'നമസ്കാരം, ഞാൻ കോറ, നിങ്ങളുടെ ഷോപ്പിംഗ് അസിസ്റ്റന്റ്. ഉൽപ്പന്നങ്ങൾ കണ്ടെത്താനും കാർട്ട് നിറയ്ക്കാനും നിങ്ങളുടെ ഓർഡർ വാട്സ്ആപ്പിനായി തയ്യാറാക്കാനും ഞാൻ സഹായിക്കാം. നിങ്ങൾ എന്താണ് തിരയുന്നത്?',
    set: 'ശരി, ഇനി മുതൽ മലയാളത്തിൽ സംസാരിക്കാം.', tap: 'മൈക്ക് അമർത്തുക അല്ലെങ്കിൽ ടൈപ്പ് ചെയ്യുക', type: 'നിങ്ങളുടെ സന്ദേശം ടൈപ്പ് ചെയ്യുക', listen: 'കേൾക്കുന്നു…', think: 'ചിന്തിക്കുന്നു…', speak: 'സംസാരിക്കുന്നു…',
    novoice: 'ഈ ഉപകരണത്തിൽ മലയാളം ശബ്ദം ഇൻസ്റ്റാൾ ചെയ്തിട്ടില്ല, അതിനാൽ മറുപടികൾ വാചകമായി മാത്രം കാണിക്കും.', noheard: 'ഒന്നും കേൾക്കാനായില്ല. വീണ്ടും ശ്രമിക്കുക.', blocked: 'മൈക്രോഫോൺ തടഞ്ഞിരിക്കുന്നു. അഡ്രസ് ബാറിൽ അനുവദിക്കുക.',
    err: 'നിങ്ങളെ കേൾക്കാനായില്ല. വീണ്ടും ശ്രമിക്കുക.', nosr: 'വോയ്സ് ഇൻപുട്ട് Android-ലെയും ഡെസ്ക്ടോപ്പിലെയും Chrome-ൽ പ്രവർത്തിക്കും. നിങ്ങൾക്ക് ടൈപ്പ് ചെയ്യുകയും ചെയ്യാം.', busy: 'കോറ ഇപ്പോൾ തിരക്കിലാണ്. കുറച്ച് സെക്കൻഡ് കഴിഞ്ഞ് വീണ്ടും ശ്രമിക്കുക.', fail: 'എന്തോ പിഴവ് സംഭവിച്ചു. വീണ്ടും ശ്രമിക്കുക.' } }
};
let lang = store.get('kora_lang', 'en-IN');
if (!LANGS[lang]) lang = 'en-IN';                     // default: English
const T = () => LANGS[lang].t;
const langSel = $('#lang');
if (langSel) { langSel.innerHTML = Object.entries(LANGS).map(([c, l]) => `<option value="${c}">${l.label}</option>`).join(''); langSel.value = lang; }

const synth = 'speechSynthesis' in window ? window.speechSynthesis : null;
let voices = [];
const loadVoices = () => { voices = synth ? synth.getVoices() : []; };
if (synth) { loadVoices(); synth.addEventListener?.('voiceschanged', loadVoices); }

const setState = t => { $('#state').textContent = t; };
const idle = () => setState(SR ? T().tap : T().type);
function paintMute() {
  const b = $('#mute');
  b.innerHTML = ic(voiceOn ? 'volume' : 'mute'); b.setAttribute('aria-pressed', String(!voiceOn)); b.setAttribute('aria-label', voiceOn ? 'Turn voice off' : 'Turn voice on');
}
paintMute();

function bubble(t, cls) {
  const d = document.createElement('div'); d.className = 'm ' + cls; d.textContent = t; if (cls !== 'u') d.lang = lang; log.append(d); log.scrollTop = log.scrollHeight; return d;
}
function typing(on) {
  $('#typing')?.remove();
  if (!on) return;
  const d = document.createElement('div'); d.id = 'typing'; d.className = 'm a typing'; d.innerHTML = '<i></i><i></i><i></i>'; log.append(d); log.scrollTop = log.scrollHeight;
}
function showView(v) {
  const c = ['Seeds', 'Fertilizers', 'Crop Care', 'Farm Tools'].includes(v.category) ? v.category : 'All';
  const so = ['low', 'high'].includes(v.sort) ? v.sort : 'featured';
  if (!ON_SHOP) { location.href = '/shop' + (c !== 'All' || so !== 'featured' ? '?' + new URLSearchParams({ ...(c !== 'All' && { cat: c }), ...(so !== 'featured' && { sort: so }) }) : ''); return; }
  cat = c; sort = so; query = ''; syncSearch(); $('#sort').value = sort;
  renderShop();
  toggleAI(false);
  setTimeout(() => $('#shop').scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth' }), 200);
}
function pcAct(p) {
  const q = qtyOf(p.id);
  return q
    ? `<div class="stepper" aria-label="Quantity of ${esc(p.name)}"><button type="button" data-d="-1" data-id="${p.id}" aria-label="One less">${ic(q === 1 ? 'trash' : 'minus')}</button><output>${q}</output><button type="button" data-d="1" data-id="${p.id}" aria-label="One more">${ic('plus')}</button></div>`
    : `<button class="btn btn-dark add" type="button" data-add="${p.id}">${ic('plus')}Add to cart</button>`;
}
function paintChatCards() {
  $$('.pc[data-pc]').forEach(el => { const p = P.find(x => x.id === +el.dataset.pc); const a = $('.pc-act', el); if (p && a) a.innerHTML = pcAct(p); });
}
function productCards(ids, view) {
  const items = [...new Set(ids)].map(id => P.find(p => p.id === id)).filter(Boolean);
  if (!items.length) return;
  const n = items.length;
  const label = view ? (view.category && view.category !== 'All' ? `${n} ${view.category} products` : `All ${n} products`) : `${n} ${n === 1 ? 'product' : 'products'} found`;
  const wrap = document.createElement('div'); wrap.className = 'pc-wrap';
  wrap.innerHTML = `<div class="pc-head">${esc(label)}</div><div class="pc-grid">${items.map(p => `<article class="pc" data-pc="${p.id}">
    <button class="pc-im" type="button" data-qv="${p.id}" aria-label="View details of ${esc(p.name)}"><img loading="lazy" alt="" width="800" height="600" src="${esc(p.image)}">${p.badge ? `<span class="flag${p.badge === 'New' ? ' new' : ''}">${esc(p.badge)}</span>` : ''}</button>
    <div class="pc-b"><span class="pc-cat">${esc(p.category)}</span><button class="pc-n" type="button" data-qv="${p.id}">${esc(p.name)}</button><p class="pc-d">${esc(p.desc)}</p>
    <div class="pc-row"><span class="pc-p">${inr(p.price)}</span><div class="pc-act">${pcAct(p)}</div></div><button class="btn btn-buy pc-buy" type="button" data-buy="${p.id}">${ic('bag')}Buy now</button></div></article>`).join('')}</div>${view ? `<button class="btn btn-quiet pc-more" type="button" data-shopview='${esc(JSON.stringify(view))}'>See these on the shop page</button>` : ''}`;
  log.append(wrap);
  log.scrollTop += wrap.getBoundingClientRect().top - log.getBoundingClientRect().top - 56;
}
/* ---- speaking: only ever in the selected language ---- */
const speechText = t => String(t)
  .replace(/₹\s?([\d,]+(?:\.\d+)?)/g, (m, n) => n.replace(/,/g, '') + ' ' + LANGS[lang].rs)
  .replace(/[*_`#>~]+/g, ' ').replace(/\p{Extended_Pictographic}/gu, ' ').replace(/\s+/g, ' ').trim();
function speechChunks(text) {                          // short pieces: long text makes Chrome stop talking after ~15 s
  const parts = text.match(/[^.!?।॥\n]+[.!?।॥]*/g) || [text], out = [];
  let cur = '';
  for (const p of parts) { if (cur && (cur + ' ' + p).length > 170) { out.push(cur.trim()); cur = p; } else cur += ' ' + p; }
  if (cur.trim()) out.push(cur.trim());
  return out;
}
function pickVoice(code) {
  const pre = code.slice(0, 2).toLowerCase(), norm = v => v.lang.replace('_', '-').toLowerCase();
  const c = voices.filter(v => norm(v).startsWith(pre));
  return c.find(v => norm(v) === code.toLowerCase() && !/compact/i.test(v.name)) || c.find(v => /google|natural|neural|online/i.test(v.name)) || c[0] || null;
}
let speakId = 0, unlocked = false; const warned = {};
function stopSpeak() { speakId++; synth?.cancel(); audioEl?.pause(); audioEl = null; }
function unlockVoice() {                               // iOS and some Android browsers only speak after a tap
  if (unlocked || !synth) return; unlocked = true;
  try { const u = new SpeechSynthesisUtterance(' '); u.volume = 0; synth.speak(u); } catch { /* ignore */ }
}
let audioEl = null;
function speakServer(parts, id) {                       // no voice on this device: play the server's voice for this language
  const next = i => {
    if (id !== speakId) return;
    if (i >= parts.length) return idle();
    audioEl = new Audio('/api/tts?lang=' + encodeURIComponent(lang) + '&q=' + encodeURIComponent(parts[i]));
    audioEl.onplaying = () => { if (id === speakId) setState(T().speak); };
    audioEl.onended = () => next(i + 1);
    audioEl.onerror = () => { if (id !== speakId) return; if (!warned.srv) { warned.srv = 1; bubble(T().novoice, 'a err'); } idle(); };
    audioEl.play().catch(() => { if (id === speakId) idle(); });
  };
  next(0);
}
function speak(text) {
  if (!voiceOn || !text) return;
  const id = ++speakId; synth?.cancel(); audioEl?.pause(); audioEl = null;
  if (synth && !voices.length) loadVoices();
  const v = synth ? pickVoice(lang) : null;
  const parts = speechChunks(speechText(text)); if (!parts.length) return;
  if (!v && (lang !== 'en-IN' || !synth)) return speakServer(parts, id);   // never read Telugu/Hindi/Malayalam with an English voice
  const next = i => {
    if (id !== speakId) return;
    if (i >= parts.length) return idle();
    const u = new SpeechSynthesisUtterance(parts[i]);
    if (v) u.voice = v; u.lang = v?.lang || lang; u.rate = 0.95;
    u.onstart = () => { if (id === speakId) setState(T().speak); };
    u.onend = () => next(i + 1);
    u.onerror = e => { if (e.error !== 'interrupted' && e.error !== 'canceled') idle(); };
    synth.speak(u);
  };
  setTimeout(() => next(0), 80);                       // Chrome drops speech started right after cancel()
}
function listen() {
  unlockVoice();
  if (!SR) return bubble(T().nosr, 'a err');
  if (listening) { rec.stop(); return; }
  stopSpeak();
  rec = new SR(); rec.lang = lang; rec.interimResults = true; rec.maxAlternatives = 1;
  heard = '';
  rec.onstart = () => { listening = true; $('#mic').classList.add('live'); setState(T().listen); };
  rec.onresult = e => { heard = [...e.results].map(r => r[0].transcript).join(''); $('#q').value = heard; };
  rec.onerror = e => setState(e.error === 'not-allowed' || e.error === 'service-not-allowed' ? T().blocked : e.error === 'no-speech' ? T().noheard : T().err);
  rec.onend = () => {
    listening = false; $('#mic').classList.remove('live');
    const t = heard.trim();
    if (t) { $('#q').value = ''; send(t); }
    else if (!busy && $('#state').textContent === T().listen) idle();
  };
  try { rec.start(); } catch { /* already started */ }
}

const thumbs = list => `<ul class="ofm-items">${list.map(r => `<li><img alt="" src="${esc(r.image)}"><span>${esc(r.name)}<small>${r.qty} × ${inr(r.price)}</small></span><b>${inr(r.price * r.qty)}</b></li>`).join('')}</ul>`;
function orderDone(o) {
  lastOrder = o; prepareCard(o);
  $$('.ofm-wrap', log).forEach(x => x.remove());
  const w = document.createElement('div'); w.className = 'm ofm-wrap';
  w.innerHTML = `<div class="ofm done"><div class="ofm-h"><b>Order ${esc(o.id)} confirmed</b><span>${inr(o.total)}</span></div>${thumbs(o.items.map(i => ({ image: i.image, name: i.name, qty: i.qty, price: i.price })))}
    <p class="muted">Last step: send your order to the store on WhatsApp. The product pictures go with it.</p>
    <a class="btn btn-wa wide" target="_blank" rel="noopener" href="${esc(o.whatsapp_url)}" data-sharepic>${ic('whatsapp')}Send order on WhatsApp</a>
    ${o.customer_whatsapp_url ? `<a class="btn btn-quiet wide" target="_blank" rel="noopener" href="${esc(o.customer_whatsapp_url)}">${ic('whatsapp')}Send confirmation to my WhatsApp</a>` : ''}
    <p class="tk-alt"><a target="_blank" rel="noopener" href="${esc(o.whatsapp_url)}">Send text only</a></p></div>`;
  log.append(w); log.scrollTop = log.scrollHeight;
}
/* ---- the delivery form, shown inside the assistant ---- */
function orderForm() {
  const r = rows();
  if (!r.length) { bubble('Your cart is empty. Tell me what you need and I will add it.', 'a'); return; }
  $$('.ofm-wrap', log).forEach(x => x.remove());
  const s = sums(), w = document.createElement('div'); w.className = 'm ofm-wrap';
  const fld = (n, l, ex = '') => `<label class="f">${l}<input name="${n}" ${ex}><span class="err"></span></label>`;
  w.innerHTML = `<form class="ofm" novalidate><div class="ofm-h"><b>Delivery details</b><span>${inr(s.tot)}${s.del ? '' : ' · free delivery'}</span></div>${thumbs(r.map(x => ({ image: x.p.image, name: x.p.name, qty: x.qty, price: x.p.price })))}
    <button class="locate" type="button" data-loc>${ic('pin')}<span><b>Use my current location</b><small>Fills in your address and adds a map pin</small></span></button>
    ${fld('name', 'Full name', 'autocomplete="name"')}${fld('phone', 'Mobile number', 'inputmode="numeric" autocomplete="tel"')}
    <label class="f">Delivery address<textarea name="address" rows="2" autocomplete="street-address"></textarea><span class="err"></span></label>
    <div class="two">${fld('pincode', 'Pincode', 'inputmode="numeric" maxlength="6"')}${fld('landmark', 'Landmark')}</div>
    <div class="pay"><label><input type="radio" name="payment" value="cod" checked> Cash on delivery</label><label><input type="radio" name="payment" value="upi"> UPI / card</label></div>
    <p class="formerr" hidden></p><button class="btn btn-buy wide" type="submit"><span>Place order</span></button></form>`;
  log.append(w); log.scrollTop = log.scrollHeight;
  const f = $('form', w), E = n => f.elements[n];
  for (const k of ['name', 'phone', 'address', 'pincode', 'landmark']) if (profile[k]) E(k).value = k === 'phone' ? fmtPhone(profile[k]) : profile[k];
  const bad = (n, m) => { const fe = E(n).closest('.f'); fe.classList.toggle('bad', !!m); $('.err', fe).textContent = m || ''; return !m; };
  f.addEventListener('input', e => e.target.closest('.f')?.classList.remove('bad'));
  $('[data-loc]', w).addEventListener('click', async e => {
    const b = e.currentTarget, sm = $('small', b); b.classList.add('busy'); sm.textContent = 'Asking your device for its location…';
    try { const g = await detectLocation(); if (g.found) { E('address').value = profile.address; if (profile.pincode) E('pincode').value = profile.pincode; } sm.textContent = g.found ? 'Address filled in. Please check it.' : 'Map pin saved. Type the street address.'; }
    catch (err) { sm.textContent = err.message; }
    b.classList.remove('busy');
  });
  f.addEventListener('submit', async e => {
    e.preventDefault();
    const ph = String(E('phone').value).replace(/\D/g, '').replace(/^(91|0)(?=\d{10}$)/, '');
    const ok = [bad('name', E('name').value.trim().length < 2 ? 'Enter your full name' : ''), bad('phone', /^[6-9]\d{9}$/.test(ph) ? '' : 'Enter a 10-digit mobile number'),
      bad('address', E('address').value.trim().length < 8 ? 'Enter your full delivery address' : ''), bad('pincode', /^(\d{6})?$/.test(E('pincode').value.trim()) ? '' : 'Pincode has 6 digits')];
    if (ok.includes(false)) return f.querySelector('.bad input,.bad textarea')?.focus();
    const btn = $('button[type=submit]', f), fe = $('.formerr', f); btn.disabled = true; $('span', btn).textContent = 'Placing your order…'; fe.hidden = true;
    const v = Object.fromEntries(new FormData(f));
    try {
      const res = await fetch('/api/order', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ cart, ...v, phone: ph, location: profile.location || null }) });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || 'Could not place the order. Please try again.');
      profile = { ...profile, name: v.name.trim(), phone: ph, address: v.address.trim(), pincode: v.pincode.trim(), landmark: v.landmark.trim() }; store.set('kora_profile', profile);
      setCart([]); orderDone(d); const msg = 'Your order ' + d.id + ' is saved. Tap the green button to send it to the store on WhatsApp.'; hist.push({ role: 'assistant', content: msg }); speak(msg);
    } catch (err) { fe.textContent = navigator.onLine ? err.message : 'You are offline. Connect to the internet and try again.'; fe.hidden = false; btn.disabled = false; $('span', btn).textContent = 'Place order'; }
  });
}
async function send(text) {
  text = (text || '').trim();
  if (!text || busy) return;
  unlockVoice();
  $('#q').value = ''; bubble(text, 'u'); hist.push({ role: 'user', content: text });
  busy = true; setState(T().think); typing(true);
  try {
    const r = await fetch('/api/chat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ messages: hist, cart, profile, lang }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(r.status === 429 ? T().busy : (d.error || T().fail));
    typing(false);
    setCart(d.cart);
    hist.push({ role: 'assistant', content: d.reply });
    if (d.reply) bubble(d.reply, 'a');
    productCards(d.products || [], d.view);
    if (d.form && !d.order) orderForm();
    speak(d.reply); if (!voiceOn) idle();
    if (d.order) {
      profile = { ...profile, name: d.order.name, phone: d.order.phone, address: d.order.address };
      store.set('kora_profile', profile);
      orderDone(d.order);
    }
  } catch (err) {
    typing(false);
    bubble(!navigator.onLine ? 'You are offline. Connect to the internet and try again.' : err instanceof TypeError ? T().fail : err.message, 'a err'); setState(T().fail);
  }
  busy = false;
}
function toggleAI(open) {
  if (open) {
    openLayer('ai', { focus: false });
    unlockVoice();
    if (!log.children.length) { const g = T().greet; bubble(g, 'a'); speak(g); }
    idle();
    if (matchMedia('(pointer:fine)').matches) setTimeout(() => $('#q').focus({ preventScroll: true }), 80);
  } else { stopSpeak(); if (listening) rec.stop(); closeLayer('ai'); }
}
$('#chatForm').addEventListener('submit', e => { e.preventDefault(); send($('#q').value); });
$('#mic').addEventListener('click', listen);
$('#mute').addEventListener('click', () => { voiceOn = !voiceOn; store.set('kora_voice', voiceOn); paintMute(); if (!voiceOn) { stopSpeak(); idle(); } });
langSel?.addEventListener('change', e => {
  lang = LANGS[e.target.value] ? e.target.value : 'en-IN'; store.set('kora_lang', lang);
  stopSpeak(); if (listening) rec.stop();
  unlockVoice(); idle();
  const m = T().set; bubble(m, 'a'); hist.push({ role: 'assistant', content: m }); speak(m);   // confirms by voice in the new language
});
$('#hints').addEventListener('click', async e => {
  const b = e.target.closest('button'); if (!b) return;
  if (b.dataset.act === 'loc') {
    try { const r = await detectLocation(); send(r.found ? 'Please deliver to my current location.' : 'I shared my map pin. Please deliver to my current location.'); }
    catch (err) { bubble(err.message, 'a err'); }
  } else if (b.dataset.act === 'form') orderForm();
  else send(b.textContent);
});

/* ------------------------------------------------------------- PWA install */
let deferred = null;
const standalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone;
addEventListener('beforeinstallprompt', e => {
  e.preventDefault(); deferred = e;
  if (standalone()) return;
  $$('[data-install]').forEach(b => { if (b.closest('#installBar')) return; b.hidden = false; });
  if (!store.get('kora_install_dismissed', false) && !matchMedia('(min-width:960px)').matches && $('#installBar')) $('#installBar').hidden = false;
});
addEventListener('appinstalled', () => { deferred = null; $$('[data-install]').forEach(b => b.hidden = true); if ($('#installBar')) $('#installBar').hidden = true; toast('Kora is installed'); });
document.addEventListener('click', async e => {
  if (!e.target.closest('[data-install]') || !deferred) return;
  deferred.prompt();
  try { await deferred.userChoice; } catch { /* ignore */ }
  deferred = null; $$('[data-install]').forEach(b => b.hidden = true); if ($('#installBar')) $('#installBar').hidden = true;
});
$('#installX')?.addEventListener('click', () => { $('#installBar').hidden = true; store.set('kora_install_dismissed', true); });
if ('serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));

/* ------------------------------------------------------------ global clicks */
document.addEventListener('click', async e => {
  const t = e.target;
  const sp = t.closest('[data-sharepic]'); if (sp) { await sendWithPictures(e, sp); return; }
  const sv = t.closest('[data-shopview]'); if (sv) { try { showView(JSON.parse(sv.dataset.shopview)); } catch { /* ignore */ } return; }
  const buy = t.closest('[data-buy]'); if (buy) { buyNow(+buy.dataset.buy); return; }
  const add = t.closest('[data-add]'); if (add) { const id = +add.dataset.add; change(id, 1); toast('Added: ' + (P.find(p => p.id === id)?.name || 'item')); return; }
  const d = t.closest('[data-d]'); if (d) { change(+d.dataset.id, +d.dataset.d); return; }
  const qv = t.closest('[data-qv]'); if (qv) { openPdp(+qv.dataset.qv); return; }
  const cl = t.closest('[data-copylink]'); if (cl) { try { await navigator.clipboard.writeText(cl.dataset.copylink); toast('Link copied'); } catch { toast('Could not copy the link'); } return; }
  const chip = t.closest('[data-chip]'); if (chip) { cat = chip.dataset.chip; renderShop(); return; }
  const c = t.closest('[data-cat]');
  if (c) { if (ON_SHOP) { cat = c.dataset.cat; query = ''; syncSearch(); renderShop(); $('#shop').scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth' }); } else location.href = '/shop?cat=' + encodeURIComponent(c.dataset.cat); return; }
  if (t.closest('[data-open-ai]')) { toggleAI(true); return; }
  const x = t.closest('[data-close]'); if (x) { const layer = x.closest('.drawer,.sheet,.ai'); if (layer?.id === 'ai') toggleAI(false); else if (layer) closeLayer(layer); }
});
$('#cartBtn').onclick = $('#navCart').onclick = () => { renderCart(); openLayer('drawer'); };
$('#checkout').onclick = openCheckout;
$('#locBtn').onclick = e => onLocClick(e.currentTarget);

/* search: the box in the header and the one on the shop page share one query */
const syncSearch = () => { for (const el of [$('#search')]) if (el) el.value = query; };
const setQuery = v => { query = v; syncSearch(); renderShop(); };
$('#search').addEventListener('input', e => { if (ON_SHOP) setQuery(e.target.value); });
$('#searchForm').addEventListener('submit', e => { if (!ON_SHOP) return; e.preventDefault(); $('#search').blur(); $('#shop').scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth' }); });
$('#sort')?.addEventListener('change', e => { sort = e.target.value; renderShop(); });
$('#clearFilters')?.addEventListener('click', () => { cat = 'All'; setQuery(''); });

/* --------------------------------------------------------------------- init */
async function init() {
  renderLoc(); renderCart();
  try {
    const [cr, pr] = await Promise.all([fetch('/api/config'), fetch('/api/products')]);
    if (cr.ok) cfg = { ...cfg, ...(await cr.json()) };
    if (!pr.ok) throw new Error('products');
    P = await pr.json();
  } catch {
    const g = $('#grid');
    if (g) g.innerHTML = `<div class="empty-state" style="grid-column:1/-1">${ic('alert').replace('class="i"', 'class="i big"')}<h3>Could not load products</h3><p class="muted">Check your connection and try again.</p><button class="btn btn-dark" onclick="location.reload()" type="button">Reload</button></div>`;
    return;
  }
  $$('[data-free]').forEach(s => s.textContent = Number(cfg.freeAbove).toLocaleString('en-IN'));
  $$('[data-fee]').forEach(s => s.textContent = Number(cfg.fee).toLocaleString('en-IN'));
  const wa = $('#waContact'); if (wa) { if (cfg.whatsapp) wa.href = 'https://wa.me/' + cfg.whatsapp; else wa.hidden = true; }
  cart = cart.filter(c => P.some(p => p.id === c.id));
  const q = new URLSearchParams(location.search);
  if (ON_SHOP) {                                         // /shop?cat=Seeds&sort=low&q=tomato
    if (new Set(P.map(p => p.category)).has(q.get('cat'))) cat = q.get('cat');
    if (['low', 'high', 'name'].includes(q.get('sort'))) { sort = q.get('sort'); $('#sort').value = sort; }
    if (q.get('q')) query = q.get('q');
    syncSearch();
  }
  renderCats(); renderShop(); renderCart();
  const pid = Number(q.get('buy') || q.get('add'));      // /shop?buy=3 comes from shared product links
  if (pid && P.some(p => p.id === pid)) {
    history.replaceState(null, '', location.pathname);
    if (q.get('buy')) buyNow(pid); else { change(pid, 1); openLayer('drawer'); }
  }
  if (q.get('ai')) toggleAI(true);
  if (q.get('cart')) openLayer('drawer');
}
init();
})();
