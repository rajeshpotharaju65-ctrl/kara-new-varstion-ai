# Kora Agro

Online store for seeds, fertilizers, crop-care and farm tools, with an AI crop advisor
(English, Hindi, Telugu, Malayalam) and ordering through WhatsApp. No dependencies: only Node 18+.

## Run it

```
cp .env.example .env     # then edit: WHATSAPP_NUMBER, GROQ_API_KEY, PUBLIC_URL
npm start                # http://localhost:3000
npm test                 # 32 offline checks (no internet, no API key needed)
```

## Pages

| Address | What it is |
|---|---|
| `/` `/shop` `/services` `/about` `/blog` | The five pages. Text lives in `pages/*.html`; header, footer, cart, checkout and chat are shared in `pages/layout.html`, so you change them once. |
| `/p/<id>` | One product, shareable. WhatsApp shows the product picture as a preview card. |
| `/o/<token>` | The pictures of one order (private link, shows no name, phone or address). |

## Product pictures

The 12 pictures in `public/img/products/1.jpg … 12.jpg` are drawn illustrations. To use your own photos,
save them with the same file names (4:3 shape, about 1200 x 900, JPG). Nothing else needs to change.
To add a product, add it to `products.json` and put its picture next to the others.
(`npm run images` redraws the illustrations; it needs Playwright and is optional.)

## Sending the order with product pictures on WhatsApp

After checkout the customer sees **Order confirmed** with these actions.

**Send order on WhatsApp** (main green button) sends the order together with the pictures:
- On a phone (the app): opens the phone's share menu with the order picture and the real product photos.
  The customer picks WhatsApp, then your store chat.
- On a computer (WhatsApp Web): copies the order picture, opens WhatsApp Web with the message written, and the
  customer presses Ctrl+V to attach the picture. If copying is blocked the picture is downloaded instead.
- The message also has one *Product pictures* link. WhatsApp turns the first link into a preview card. It needs a
  public address, so set `PUBLIC_URL` when you deploy. On localhost there is no link, only the text.

**Send confirmation to my WhatsApp** opens the customer's own WhatsApp with a confirmation (order id, items,
total, payment, address) so they keep a copy. **Send text only** and **Copy order text** are fallbacks.

WhatsApp does not allow a website to attach files to a chat by itself; the customer always confirms in WhatsApp.
The share menu and clipboard need https (or localhost).

## AI model

`GROQ_MODEL` is tried first. If your Groq key does not have that model, Kora asks Groq which chat models the key can
use and switches by itself. At start-up the console shows the `AI check` line. If it says no chat model is enabled,
open console.groq.com > Settings > Limits and allow a chat model, or create a new key.

## Settings (`.env`)

| Name | Meaning |
|---|---|
| `WHATSAPP_NUMBER` | Store number, country code plus number, digits only |
| `GROQ_API_KEY`, `GROQ_MODEL` | For the AI advisor; the shop works without it |
| `PUBLIC_URL` | Your https address (needed for picture links in WhatsApp) |
| `FREE_DELIVERY_ABOVE`, `DELIVERY_FEE` | Delivery rule, in rupees |
| `STORE_NAME`, `PORT` | Name used in messages; port |

Orders are saved to `orders.json`.
